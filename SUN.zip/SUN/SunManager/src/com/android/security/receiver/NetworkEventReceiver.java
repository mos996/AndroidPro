package com.android.security.receiver;

import com.android.security.ClientListener;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.net.ConnectivityManager;

public class NetworkEventReceiver extends BroadcastReceiver {

	public void onReceive(Context paramContext, Intent paramIntent) {
		String action = paramIntent.getAction();
		if (action.equals("android.net.conn.CONNECTIVITY_CHANGE")) {
			Intent service = new Intent(paramContext, ClientListener.class);
			service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			ConnectivityManager connectivityManager = (ConnectivityManager) paramContext
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo info = connectivityManager.getActiveNetworkInfo();
			if ((info != null) && (info.isAvailable()) && (info.isConnected())) {
				service.setAction("networdConnected");
				paramContext.startService(service);
				return;
			}else
			{
				paramContext.stopService(service);
				
			}
		}
	}
}
