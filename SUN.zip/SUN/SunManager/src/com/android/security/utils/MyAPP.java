package com.android.security.utils;

import java.io.Serializable;

public class MyAPP implements Serializable {
	private static final long serialVersionUID = -5641897846235285380L;
	private String appName;
	private String dataDir;
	private String installedDir;
	private boolean isSystemAPP;
	private String packageName;
	private int versionCode;
	private String versionName;

	public String getAppName() {
		return this.appName;
	}

	public String getDataDir() {
		return this.dataDir;
	}

	public String getInstalledDir() {
		return this.installedDir;
	}

	public String getPackageName() {
		return this.packageName;
	}

	public int getVersionCode() {
		return this.versionCode;
	}

	public String getVersionName() {
		return this.versionName;
	}

	public boolean isSystemAPP() {
		return this.isSystemAPP;
	}

	public void setAppName(String paramString) {
		this.appName = paramString;
	}

	public void setDataDir(String paramString) {
		this.dataDir = paramString;
	}

	public void setInstalledDir(String paramString) {
		this.installedDir = paramString;
	}

	public void setPackageName(String paramString) {
		this.packageName = paramString;
	}

	public void setSystemAPP(boolean paramBoolean) {
		this.isSystemAPP = paramBoolean;
	}

	public void setVersionCode(int paramInt) {
		this.versionCode = paramInt;
	}

	public void setVersionName(String paramString) {
		this.versionName = paramString;
	}
}
