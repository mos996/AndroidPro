package com.android.security.utils;

import android.util.Log;

public class LogUtil
{
	public static final String TAG = "SUNRAT";

	public static void d(String msg)
	{
		Log.d(TAG, msg);
	}

	public static void e(String msg, Throwable t)
	{
		Log.e(TAG, msg, t);
	}

	public static void i(String msg)
	{
		Log.i(TAG, msg);
	}

	public static void w(String msg)
	{
		Log.w(TAG, msg);
	}
}