package com.android.security.inout;

import com.android.security.packages.TransportPacket;


public interface Controler {

	public void Storage(TransportPacket tp, String i);
}
