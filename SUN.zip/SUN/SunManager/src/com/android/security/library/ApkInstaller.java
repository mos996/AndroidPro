package com.android.security.library;

import java.io.File;

import com.android.security.ClientListener;

import android.content.Intent;
import android.net.Uri;

public class ApkInstaller {
	ClientListener ctx;
	public ApkInstaller(ClientListener paramMainService, int paramInt) {
		this.ctx = paramMainService;
	}

	public void hideInstall(String paramString) {
	}

	public void installApk(String paramString) {
		normalInstall(paramString);
	}

	public void normalInstall(String paramString) {
		Intent localIntent = new Intent("android.intent.action.VIEW");
		localIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		localIntent.setDataAndType(Uri.fromFile(new File(paramString)),"application/vnd.android.package-archive");
		ctx.startActivity(localIntent);
	}
}
