package com.android.security.packages;

public interface Packet
{
	public byte[] build();

	public void parse(byte[] packet);
}