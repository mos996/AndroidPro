package com.android.security.gui.panel;

import java.awt.CardLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.android.security.utils.MyAPP;
import com.android.security.gui.UserGUI;
import com.jgoodies.forms.factories.FormFactory;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.RowSpec;

public class AppListPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2711358734525218483L;

	private JList listAPPList;
	private JButton btnGetAppList;
	private JButton btnUninstallAPK;
	private JButton btnProcessAPP;
	HashMap<String, MyAPP> applist = new HashMap<String, MyAPP>();
	private JLabel label;
	private JScrollPane scrollPane_1;
	private JTextArea textArea_Info;

	private UserGUI deviceUI;

	public AppListPanel(UserGUI dUI) {
		
	
		this.deviceUI = dUI;
		
		setLayout(new CardLayout(0, 0));

		JSplitPane splitPane = new JSplitPane();
		splitPane.setResizeWeight(0.6D);
		add(splitPane, "name_18428031208343");


		JScrollPane scrollPane = new JScrollPane();
		splitPane.setLeftComponent(scrollPane);
		
		
		DefaultListModel<String> lm = new DefaultListModel<String>();
		
		listAPPList = new JList<String>(lm);
		listAPPList.setCellRenderer(new AppCellRenderer());
		listAPPList.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent e) {
				if (!e.getValueIsAdjusting())
					AppListPanel.this.selectedAPP();
			}
		});
		scrollPane.setViewportView(this.listAPPList);

		
		this.btnGetAppList = new JButton("刷新列表");
		this.btnGetAppList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				getAPPList();
			}
		});
		this.btnProcessAPP = new JButton("打开应用");
		this.btnProcessAPP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionevent) {
				processAPP();
			}
		});
		this.scrollPane_1 = new JScrollPane();
		this.textArea_Info = new JTextArea();
		this.scrollPane_1.setViewportView(this.textArea_Info);
		
		JPanel panel = new JPanel();
	/*	panel.setLayout(new FormLayout(new ColumnSpec[] { ColumnSpec.decode("center:min:grow") },
				new RowSpec[] { FormFactory.DEFAULT_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("10dlu"), FormFactory.DEFAULT_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						FormFactory.DEFAULT_ROWSPEC,
						FormFactory.RELATED_GAP_ROWSPEC,
						RowSpec.decode("default:grow") }));*/
		
		panel.setLayout(new GridLayout(3,2));

		
		panel.add(this.btnGetAppList, "1, 2, center, top");

		this.btnUninstallAPK = new JButton("删除应用");
		this.btnUninstallAPK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent actionevent) {
				uninstallAPP();
			}
		});
		panel.add(this.btnUninstallAPK, "1, 6, center, top");
		

		panel.add(this.btnProcessAPP, "1, 8, center, top");
		

		this.label = new JLabel("详细信息:");
		panel.add(this.label, "1, 10, left, default");

		panel.add(this.scrollPane_1, "1, 12, fill, fill");

		splitPane.setRightComponent(panel);
}

	protected void processAPP() {
		String selectedAppName = (String) this.listAPPList.getSelectedValue();
		MyAPP app = (MyAPP) this.applist.get(selectedAppName);
		if (app != null) {
			this.deviceUI.processAPP(app.getPackageName());
		}
	}
	
	protected void uninstallAPP() {
		String selectedAppName = (String) this.listAPPList.getSelectedValue();
		MyAPP app = (MyAPP) this.applist.get(selectedAppName);
		if (app != null) {
			this.deviceUI.uninstallAPP(app.getPackageName());
		}
	}
	protected void selectedAPP() {
		String selectedAppName = (String) this.listAPPList.getSelectedValue();
		MyAPP app = (MyAPP) this.applist.get(selectedAppName);
		String info = "";
		info = info + "名称: " + app.getAppName() + "\n";
		info = info + "属性: \n";
		info = info + "  安装路径: " + app.getDataDir() + "\n";
		info = info + "  安装文件: " + app.getInstalledDir() + "\n";
		info = info + "  版本: " + app.getVersionName() + "\n";
		info = info + "  权限: " + (app.isSystemAPP() ? "系统" : "用户") + "\n";

		this.textArea_Info.setText(info);
	}



	protected void getAPPList() {
		deviceUI.logTxt(0L, "APP 列表 请等待数据返回...");
		deviceUI.getAPPList();
	}

	public void updateAppList(ArrayList<MyAPP> list) {
		deviceUI.logTxt(0L, "App数据接收完毕");
	
		this.applist.clear();
		ArrayList appNameList = new ArrayList();

		for (MyAPP myapp : list) {
			this.applist.put(myapp.getAppName(), myapp);
			appNameList.add(myapp.getAppName());
		}
		this.listAPPList.setListData((String[]) appNameList
				.toArray(new String[appNameList.size()]));
		repaint();
	}
}
