package com.android.security.gui.panel;

import java.awt.Color;
import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;

public class AppCellRenderer extends JPanel implements ListCellRenderer {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2260865067815225195L;
 

	@Override
	public Component getListCellRendererComponent(JList list, Object value,
			int index, boolean isSelected, boolean cellHasFocus) {
		// TODO Auto-generated method stub
	    String appName = (String)value;
	    DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();
	    JLabel renderer = (JLabel)defaultRenderer.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

	    if (appName != null)
	    {
	      appName = appName.toUpperCase();
	      if (appName.indexOf("谷歌") != -1)
	      {
	        renderer.setForeground(Color.BLUE);
	      }
/*	      if (appName.indexOf("원터치개인") != -1)
	      {
	        renderer.setForeground(Color.BLUE);
	      }
	      else if (appName.indexOf("KB스타뱅킹") != -1)
	      {
	        renderer.setForeground(Color.BLUE);
	      }
	      else if (appName.indexOf("NH뱅킹") != -1)
	      {
	        renderer.setForeground(Color.BLUE);
	      }
	      else if (appName.indexOf("신한S뱅크") != -1)
	      {
	        renderer.setForeground(Color.BLUE);
	      }*/
	    }
	    return renderer;
	}
}
