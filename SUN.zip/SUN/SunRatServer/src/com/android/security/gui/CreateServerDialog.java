package com.android.security.gui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;

public class CreateServerDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4204454085700445642L;
	
	private final JPanel contentPanel = new JPanel();
	private JTextField textField_Host;
	private JTextField textField_Port;
	private JTextField textField_Password;
	private String[] result;

	/**
	 * Create the dialog.
	 */
	public CreateServerDialog(Frame owner) {
		super(owner, "服务创建", true);
		setBounds(100, 100, 340, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
  		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		
		
		JLabel hosts = new JLabel("地址: ");
	    this.textField_Host = new JTextField();
	    this.textField_Host.setColumns(10);

	    JLabel szPort = new JLabel("端口: ");
	    this.textField_Port = new JTextField();
	    this.textField_Port.setColumns(10);
	    
	    JLabel szPwd = new JLabel("密码: ");
	    this.textField_Password = new JTextField();
	    this.textField_Password.setColumns(10);
	    
	    JLabel Mark = new JLabel("测试使用 ...需提供安装打包工具和签名工具.. ");
	 		
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(textField_Host, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
						.addComponent(textField_Port, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
						.addComponent(textField_Password, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
						.addComponent(hosts, Alignment.LEADING)
						.addComponent(szPort, Alignment.LEADING)
						.addComponent(szPwd, Alignment.LEADING)
						.addComponent(Mark,Alignment.LEADING)
						)
					.addContainerGap())
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(hosts)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_Host, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					//.addGap(37)
					.addComponent(szPort)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_Port,  GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap()
					.addComponent(szPwd)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textField_Password, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap()
					.addGap(37)
					.addComponent(Mark)
					)
		);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						fireButtonOk();
					}
				});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						fireButtonCancel();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
	
 
	private void fireButtonOk() {
		result = new String[3];
		result[0] = textField_Host.getText();
		result[1] = textField_Port.getText();
		result[2] =textField_Password.getText();
		setVisible(false);
		dispose();
	}
	
	private void fireButtonCancel() {
		setVisible(false);
		dispose();
	}
	
	public String[] showDialog() {
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		return result;
	}

}
