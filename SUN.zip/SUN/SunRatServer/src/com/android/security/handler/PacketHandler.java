package com.android.security.handler;


import com.android.security.gui.server.Server;
import com.android.security.packages.Packet;

 
public interface PacketHandler 
{
   public void receive(Packet p,String imei);

   public void handlePacket(Packet p, String temp_imei, Server c);

}
